# Frontend Demo & Testing Guide

## 🎉 Xin chúc mừng!

Frontend đã được xây dựng thành công và sẵn sàng sử dụng!

## 📋 Quick Start

1. **Server đang chạy tại**: http://localhost:3000
2. **Mở trình duyệt** và truy cập URL trên
3. **Bắt đầu sử dụng** ngay!

## 🧪 Test Flow (Khuyến nghị)

### Bước 1: Đăng ký tài khoản
```
1. Click "Đăng ký" ở góc trên phải
2. Nhập:
   - Email: test@example.com
   - Password: 123456
   - Confirm Password: 123456
3. Click "Đăng ký"
```

### Bước 2: Đăng nhập
```
1. Click "Đăng nhập"
2. Nhập:
   - Email: test@example.com
   - Password: 123456
3. Click "Đăng nhập"
```

### Bước 3: Thêm sản phẩm
```
1. Click "Thêm sản phẩm"
2. Nhập:
   - Mã SP: SP001
   - Tên: Laptop Dell XPS 13
   - Giá: 25000000
   - Mô tả: Laptop cao cấp cho dân văn phòng
3. Upload hình ảnh (optional)
4. Click "Lưu"
```

**Thêm thêm vài sản phẩm nữa:**

```
Sản phẩm 2:
- Mã: SP002
- Tên: iPhone 15 Pro Max
- Giá: 32000000
- Mô tả: Flagship mới nhất từ Apple

Sản phẩm 3:
- Mã: SP003
- Tên: Samsung Galaxy S24 Ultra
- Giá: 28000000
- Mô tả: Smartphone Android cao cấp

Sản phẩm 4:
- Mã: SP004
- Tên: MacBook Pro M3
- Giá: 45000000
- Mô tả: Laptop mạnh mẽ cho developer

Sản phẩm 5:
- Mã: SP005
- Tên: iPad Pro 12.9
- Giá: 28000000
- Mô tả: Máy tính bảng đa năng
```

### Bước 4: Test tìm kiếm sản phẩm
```
1. Gõ "laptop" vào ô tìm kiếm
2. Xem kết quả được filter
3. Thử tìm "iphone", "samsung", etc.
```

### Bước 5: Xem chi tiết sản phẩm
```
1. Click "Chi tiết" trên một sản phẩm bất kỳ
2. Xem thông tin đầy đủ
3. Đóng modal
```

### Bước 6: Sửa sản phẩm
```
1. Click "Sửa" trên một sản phẩm
2. Thay đổi giá: 26000000
3. Click "Lưu"
4. Kiểm tra giá đã thay đổi
```

### Bước 7: Tạo đơn hàng
```
1. Chuyển sang tab "Đơn hàng"
2. Click "Tạo đơn hàng"
3. Nhập:
   - Mã đơn hàng: ORDER001
   - Tổng giá trị: 85000000
4. Thêm sản phẩm:
   - Click "Thêm sản phẩm"
   - Mã SP: SP001 | SL: 2 | Giá: 25000000
   - Click "Thêm sản phẩm" lần 2
   - Mã SP: SP002 | SL: 1 | Giá: 32000000
5. Click "Lưu"
```

**Thêm đơn hàng thứ 2:**
```
- Mã đơn hàng: ORDER002
- Tổng giá trị: 73000000
Sản phẩm:
  - SP003 | SL: 1 | Giá: 28000000
  - SP005 | SL: 1 | Giá: 28000000
```

### Bước 8: Xem chi tiết đơn hàng
```
1. Click "Chi tiết" trên đơn hàng
2. Xem thông tin đầy đủ
3. Kiểm tra danh sách sản phẩm
```

### Bước 9: Sửa đơn hàng
```
1. Click "Sửa" trên đơn hàng
2. Thêm/xóa sản phẩm
3. Cập nhật tổng giá trị
4. Click "Lưu"
```

### Bước 10: Test xóa
```
1. Xóa 1 sản phẩm (click "Xóa")
2. Xác nhận xóa
3. Xóa 1 đơn hàng
4. Xác nhận xóa
```

### Bước 11: Đăng xuất
```
1. Click "Đăng xuất"
2. Kiểm tra các nút "Sửa", "Xóa", "Thêm" đã biến mất
3. Vẫn xem được danh sách sản phẩm/đơn hàng
```

## 🎨 UI Features to Check

### ✅ Responsive Design
- Resize browser window
- Check mobile view (< 768px)
- Check tablet view
- Check desktop view

### ✅ Animations
- Modal slide up
- Toast slide in
- Card hover effects
- Button hover effects

### ✅ Loading States
- Spinner khi load data
- Loading text

### ✅ Empty States
- Khi chưa có sản phẩm
- Khi tìm kiếm không có kết quả
- Khi chưa có đơn hàng

### ✅ Toast Notifications
- Success messages (green)
- Error messages (red)
- Warning messages (yellow)
- Info messages (blue)

### ✅ Modals
- Click outside to close
- Click X to close
- ESC to close (not implemented yet)

## 📱 Browser DevTools Testing

### Console Check
1. Mở DevTools (F12)
2. Vào tab Console
3. Không nên có lỗi đỏ
4. Các API calls thành công

### Network Tab
1. Vào tab Network
2. Thực hiện các actions
3. Check status code:
   - 200: Success
   - 201: Created
   - 401: Unauthorized
   - 404: Not Found

### Application Tab
1. Vào Application > Local Storage
2. Check có `token` và `user`
3. Đăng xuất, check token bị xóa

## 🐛 Common Issues & Solutions

### Issue 1: "Vui lòng đăng nhập"
**Solution**: Login trước khi thực hiện protected actions

### Issue 2: Token expired
**Solution**: Logout và login lại

### Issue 3: Image không hiển thị
**Solution**: 
- Check file format (jpg, png, gif)
- Check file size < 5MB
- Check server uploads folder có file không

### Issue 4: CORS error
**Solution**: CORS đã được config, restart server

### Issue 5: Không connect được MongoDB
**Solution**: 
- Check MongoDB đang chạy
- Check connection string trong .env

## 📊 Test Data Examples

### Products
```javascript
[
  {
    code: "SP001",
    name: "Laptop Dell XPS 13",
    price: 25000000,
    description: "Laptop cao cấp"
  },
  {
    code: "SP002",
    name: "iPhone 15 Pro Max",
    price: 32000000,
    description: "Flagship Apple"
  }
]
```

### Orders
```javascript
[
  {
    orderCode: "ORDER001",
    totalPrice: 85000000,
    items: [
      { productCode: "SP001", quantity: 2, price: 25000000 },
      { productCode: "SP002", quantity: 1, price: 32000000 }
    ]
  }
]
```

## 🎯 Feature Checklist

### Authentication
- [x] Register
- [x] Login
- [x] Logout
- [x] Token persistence
- [x] Protected routes

### Products
- [x] List all
- [x] View detail
- [x] Search
- [x] Create (protected)
- [x] Update (protected)
- [x] Delete (protected)
- [x] Image upload

### Orders
- [x] List all
- [x] View detail
- [x] Create (protected)
- [x] Update (protected)
- [x] Delete (protected)
- [x] Multiple items

### UI/UX
- [x] Responsive design
- [x] Toast notifications
- [x] Modals
- [x] Loading states
- [x] Empty states
- [x] Animations
- [x] Icons
- [x] Form validation

## 🚀 Next Steps

1. **Test thoroughly** tất cả các tính năng
2. **Take screenshots** của UI
3. **Document bugs** nếu có
4. **Improve UX** dựa trên feedback
5. **Add more features** nếu cần

## 📞 Support

Nếu gặp vấn đề:
1. Check Console logs
2. Check Network tab
3. Check server logs
4. Restart server
5. Clear localStorage và thử lại

## 🎓 Learning Points

Frontend này demo:
- ✅ SPA architecture
- ✅ REST API integration
- ✅ JWT authentication
- ✅ Form handling
- ✅ File upload
- ✅ Responsive design
- ✅ Modern CSS
- ✅ Vanilla JavaScript
- ✅ DOM manipulation
- ✅ Async/await patterns
- ✅ Error handling
- ✅ UX best practices

**Chúc bạn test thành công! 🎉**
