const express = require('express');
const cors = require('cors');
const rateLimit = require('express-rate-limit');
const fs = require('fs');
const path = require('path');
require('dotenv').config();

const connectDB = require('./config/database');
const { errorHandler, notFoundHandler } = require('./middlewares/errorHandler');

// Ensure uploads directory exists
const uploadsDir = path.join(__dirname, 'uploads');
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
  console.log('✅ Created uploads directory');
}

// Import routes
const accountRoutes = require('./routes/accountRoutes');
const productRoutes = require('./routes/productRoutes');
const orderRoutes = require('./routes/orderRoutes');

// Initialize express app
const app = express();

// Connect to MongoDB
connectDB();

// CORS configuration - Allow all origins
app.use(cors({
  origin: '*',
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization']
}));

// Rate limiting to prevent DDoS attacks
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100, // Limit each IP to 100 requests per windowMs
  message: {
    success: false,
    message: 'Too many requests from this IP, please try again later.'
  },
  standardHeaders: true,
  legacyHeaders: false
});

// Apply rate limiting to all API routes
app.use('/api/', limiter);

// Body parser middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve static files
app.use('/uploads', express.static('uploads'));
app.use(express.static('public'));

// API Routes
app.use('/api/account', accountRoutes);
app.use('/api/products', productRoutes);
app.use('/api/orders', orderRoutes);

// API info route
const apiInfo = {
  success: true,
  message: 'Welcome to Lab 8-9 REST API',
  version: '1.0.0',
  endpoints: {
    account: {
      register: 'POST /api/account/register',
      login: 'POST /api/account/login'
    },
    products: {
      getAll: 'GET /api/products',
      getOne: 'GET /api/products/:id',
      create: 'POST /api/products (Protected)',
      update: 'PUT /api/products/:id (Protected)',
      delete: 'DELETE /api/products/:id (Protected)'
    },
    orders: {
      getAll: 'GET /api/orders',
      getOne: 'GET /api/orders/:id',
      create: 'POST /api/orders (Protected)',
      update: 'PUT /api/orders/:id (Protected)',
      delete: 'DELETE /api/orders/:id (Protected)'
    }
  },
  documentation: {
    swagger: 'Coming soon',
    postman: 'Import Lab0809.postman_collection.json'
  }
};

// Welcome route
app.get('/', (req, res) => {
  res.json(apiInfo);
});

// API info route - same as welcome
app.get('/api', (req, res) => {
  res.json(apiInfo);
});

// 404 handler - must be after all routes
app.use(notFoundHandler);

// Error handler middleware - must be last
app.use(errorHandler);

// Start server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`🚀 Server is running on port ${PORT}`);
  console.log(`📍 API available at http://localhost:${PORT}/api`);
});

module.exports = app;
