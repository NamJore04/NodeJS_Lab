const mongoose = require('mongoose');

const orderItemSchema = new mongoose.Schema({
  productCode: {
    type: String,
    required: [true, 'Product code is required']
  },
  quantity: {
    type: Number,
    required: [true, 'Quantity is required'],
    min: [1, 'Quantity must be at least 1']
  },
  price: {
    type: Number,
    required: [true, 'Price is required'],
    min: [0, 'Price must be a positive number']
  }
}, { _id: false });

const orderSchema = new mongoose.Schema({
  orderCode: {
    type: String,
    required: [true, 'Order code is required'],
    unique: true,
    trim: true
  },
  totalPrice: {
    type: Number,
    required: [true, 'Total price is required'],
    min: [0, 'Total price must be a positive number']
  },
  products: {
    type: [orderItemSchema],
    validate: {
      validator: function(v) {
        return v && v.length > 0;
      },
      message: 'Order must contain at least one product'
    }
  }
}, {
  timestamps: true
});

module.exports = mongoose.model('Order', orderSchema);
