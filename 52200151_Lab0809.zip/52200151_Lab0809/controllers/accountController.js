const Account = require('../models/Account');
const jwt = require('jsonwebtoken');
const { validationResult } = require('express-validator');
require('dotenv').config();

// Generate JWT token
const generateToken = (userId) => {
  return jwt.sign(
    { userId },
    process.env.JWT_SECRET,
    { expiresIn: process.env.JWT_EXPIRES_IN || '7d' }
  );
};

// @desc    Register new account
// @route   POST /api/account/register
// @access  Public
exports.register = async (req, res, next) => {
  try {
    // Check validation errors
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        success: false,
        message: 'Validation failed',
        errors: errors.array()
      });
    }

    const { email, password } = req.body;

    // Check if account already exists
    const existingAccount = await Account.findOne({ email });
    if (existingAccount) {
      return res.status(400).json({
        success: false,
        message: 'Email already registered'
      });
    }

    // Create new account
    const account = await Account.create({
      email,
      password
    });

    // Generate token
    const token = generateToken(account._id);

    res.status(201).json({
      success: true,
      message: 'Account registered successfully',
      data: {
        account: {
          id: account._id,
          email: account.email
        },
        token
      }
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Login account
// @route   POST /api/account/login
// @access  Public
exports.login = async (req, res, next) => {
  try {
    // Check validation errors
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        success: false,
        message: 'Validation failed',
        errors: errors.array()
      });
    }

    const { email, password } = req.body;

    // Find account
    const account = await Account.findOne({ email }).select('+password');
    if (!account) {
      return res.status(401).json({
        success: false,
        message: 'Invalid email or password'
      });
    }

    // Check password
    const isMatch = await account.comparePassword(password);
    if (!isMatch) {
      return res.status(401).json({
        success: false,
        message: 'Invalid email or password'
      });
    }

    // Generate token
    const token = generateToken(account._id);

    res.json({
      success: true,
      message: 'Login successful',
      data: {
        account: {
          id: account._id,
          email: account.email
        },
        token
      }
    });
  } catch (error) {
    next(error);
  }
};
