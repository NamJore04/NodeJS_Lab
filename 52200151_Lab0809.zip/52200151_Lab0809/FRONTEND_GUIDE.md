# Frontend Guide - Lab 8-9 REST API

## Giới thiệu

Frontend này là một Single Page Application (SPA) được xây dựng với HTML, CSS và JavaScript thuần, không sử dụng framework để dễ hiểu và dễ học.

## Tính năng

### 1. **Quản lý tài khoản**
- ✅ Đăng ký tài khoản mới
- ✅ Đăng nhập
- ✅ Đăng xuất
- ✅ Lưu trữ token trong localStorage

### 2. **Quản lý sản phẩm**
- ✅ Xem danh sách sản phẩm (công khai)
- ✅ Tìm kiếm sản phẩm theo tên, mã, mô tả
- ✅ Xem chi tiết sản phẩm
- ✅ Thêm sản phẩm mới (yêu cầu đăng nhập)
- ✅ Sửa thông tin sản phẩm (yêu cầu đăng nhập)
- ✅ Xóa sản phẩm (yêu cầu đăng nhập)
- ✅ Upload hình ảnh sản phẩm

### 3. **Quản lý đơn hàng**
- ✅ Xem danh sách đơn hàng (công khai)
- ✅ Xem chi tiết đơn hàng
- ✅ Tạo đơn hàng mới (yêu cầu đăng nhập)
- ✅ Sửa đơn hàng (yêu cầu đăng nhập)
- ✅ Xóa đơn hàng (yêu cầu đăng nhập)
- ✅ Quản lý danh sách sản phẩm trong đơn hàng

### 4. **UI/UX**
- ✅ Responsive design (hỗ trợ mobile, tablet, desktop)
- ✅ Toast notification
- ✅ Modal dialogs
- ✅ Loading states
- ✅ Empty states
- ✅ Icon với Font Awesome
- ✅ Animations và transitions

## Cấu trúc file

```
public/
├── index.html          # Trang chủ, HTML chính
├── css/
│   └── style.css      # CSS styling, responsive
└── js/
    └── app.js         # JavaScript logic, API calls
```

## Hướng dẫn sử dụng

### 1. Khởi động server

```bash
npm start
```

### 2. Truy cập ứng dụng

Mở trình duyệt và truy cập: **http://localhost:3000**

### 3. Đăng ký tài khoản

1. Click nút **"Đăng ký"** ở góc trên bên phải
2. Nhập email và mật khẩu (ít nhất 6 ký tự)
3. Xác nhận mật khẩu
4. Click **"Đăng ký"**

### 4. Đăng nhập

1. Click nút **"Đăng nhập"**
2. Nhập email và mật khẩu đã đăng ký
3. Click **"Đăng nhập"**
4. Token sẽ được lưu tự động

### 5. Quản lý sản phẩm

#### Thêm sản phẩm
1. Đăng nhập trước
2. Click **"Thêm sản phẩm"**
3. Điền thông tin:
   - Mã sản phẩm (bắt buộc)
   - Tên sản phẩm (bắt buộc)
   - Giá (bắt buộc)
   - Hình ảnh (tùy chọn)
   - Mô tả (tùy chọn)
4. Click **"Lưu"**

#### Sửa sản phẩm
1. Click nút **"Sửa"** trên card sản phẩm
2. Cập nhật thông tin
3. Click **"Lưu"**

#### Xóa sản phẩm
1. Click nút **"Xóa"** trên card sản phẩm
2. Xác nhận xóa

#### Tìm kiếm sản phẩm
- Nhập từ khóa vào ô tìm kiếm
- Kết quả hiển thị ngay lập tức

### 6. Quản lý đơn hàng

#### Tạo đơn hàng
1. Đăng nhập trước
2. Click **"Tạo đơn hàng"**
3. Điền thông tin:
   - Mã đơn hàng (bắt buộc)
   - Tổng giá trị (bắt buộc)
4. Thêm sản phẩm vào đơn hàng:
   - Click **"Thêm sản phẩm"**
   - Nhập mã sản phẩm, số lượng, giá
   - Có thể thêm nhiều sản phẩm
   - Click dấu X để xóa sản phẩm
5. Click **"Lưu"**

#### Sửa đơn hàng
1. Click nút **"Sửa"** trên card đơn hàng
2. Cập nhật thông tin
3. Click **"Lưu"**

#### Xóa đơn hàng
1. Click nút **"Xóa"** trên card đơn hàng
2. Xác nhận xóa

## API Endpoints được sử dụng

### Authentication
- `POST /api/account/register` - Đăng ký
- `POST /api/account/login` - Đăng nhập

### Products
- `GET /api/products` - Lấy danh sách sản phẩm
- `GET /api/products/:id` - Lấy chi tiết sản phẩm
- `POST /api/products` - Thêm sản phẩm (Protected)
- `PUT /api/products/:id` - Sửa sản phẩm (Protected)
- `DELETE /api/products/:id` - Xóa sản phẩm (Protected)

### Orders
- `GET /api/orders` - Lấy danh sách đơn hàng
- `GET /api/orders/:id` - Lấy chi tiết đơn hàng
- `POST /api/orders` - Tạo đơn hàng (Protected)
- `PUT /api/orders/:id` - Sửa đơn hàng (Protected)
- `DELETE /api/orders/:id` - Xóa đơn hàng (Protected)

## Code Structure

### HTML (index.html)
- Semantic HTML5
- Modals cho các form
- Sections cho Products và Orders
- Toast notification

### CSS (style.css)
- CSS Variables cho theming
- Flexbox và Grid layout
- Responsive breakpoints
- Animations và transitions
- Component-based styling

### JavaScript (app.js)
- Fetch API cho HTTP requests
- LocalStorage cho token persistence
- Event handling
- DOM manipulation
- Form validation
- Error handling

## Các tính năng nâng cao

### 1. Authentication Flow
```javascript
// Token được lưu trong localStorage
localStorage.setItem('token', token);

// Token được gửi kèm mọi request protected
headers: {
    'Authorization': `Bearer ${token}`
}
```

### 2. Image Upload
```javascript
// Upload file với FormData
const formData = new FormData();
formData.append('image', fileInput.files[0]);
```

### 3. Dynamic UI Updates
```javascript
// UI thay đổi theo trạng thái đăng nhập
if (token) {
    // Show edit/delete buttons
} else {
    // Hide protected actions
}
```

### 4. Toast Notifications
```javascript
showToast('Message', 'success'); // success, error, warning, info
```

### 5. Modal Management
```javascript
showModal('modalId');
closeModal('modalId');
```

## Browser Support

- ✅ Chrome 90+
- ✅ Firefox 88+
- ✅ Safari 14+
- ✅ Edge 90+

## Responsive Breakpoints

- **Desktop**: > 768px
- **Tablet/Mobile**: ≤ 768px

## Tips & Best Practices

1. **Always login before performing protected actions**
2. **Token expires after 24 hours** - need to login again
3. **Use valid image formats** for product images (jpg, png, gif)
4. **File size limit** for images is 5MB
5. **Search is case-insensitive** and searches in name, code, description

## Troubleshooting

### Token expired
- Logout and login again
- Token will be refreshed

### Image not showing
- Check file format (jpg, png, gif)
- Check file size (< 5MB)
- Check server is running

### Can't create product/order
- Make sure you're logged in
- Check token in localStorage
- Check console for errors

## Future Enhancements

- [ ] Pagination cho danh sách
- [ ] Advanced search filters
- [ ] Shopping cart functionality
- [ ] Order status tracking
- [ ] User profile management
- [ ] Dark mode
- [ ] Export data to PDF/Excel
- [ ] Real-time updates với WebSocket

## License

MIT License - Educational purposes only
