# Lab 8-9: REST API with Express.js, MongoDB, and JWT

REST API cho quản lý tài khoản, sản phẩm và đơn hàng với xác thực JWT.

## 📋 Mục lục
- [Tính năng](#tính-năng)
- [Công nghệ sử dụng](#công-nghệ-sử-dụng)
- [Cài đặt](#cài-đặt)
- [Cấu hình](#cấu-hình)
- [Chạy ứng dụng](#chạy-ứng-dụng)
- [API Endpoints](#api-endpoints)
- [Cấu trúc thư mục](#cấu-trúc-thư-mục)

## ✨ Tính năng

- ✅ Đăng ký và đăng nhập tài khoản
- ✅ Xác thực JWT (JSON Web Token)
- ✅ Mã hóa mật khẩu với bcrypt
- ✅ CRUD operations cho Products và Orders
- ✅ Upload hình ảnh sản phẩm với Multer
- ✅ Validation dữ liệu với express-validator
- ✅ Rate limiting chống DDoS
- ✅ CORS enabled cho tất cả origins
- ✅ Error handling toàn diện
- ✅ Kiến trúc MVC

## 🛠 Công nghệ sử dụng

- **Express.js** - Web framework
- **MongoDB** - Database
- **Mongoose** - ODM
- **JWT** - Authentication
- **Bcrypt** - Password hashing
- **Multer** - File upload
- **Express Validator** - Validation
- **Express Rate Limit** - Rate limiting
- **CORS** - Cross-Origin Resource Sharing

## 📦 Cài đặt

### 1. Clone hoặc tải project

### 2. Cài đặt dependencies

```bash
npm install
```

### 3. Cài đặt MongoDB

Đảm bảo MongoDB đã được cài đặt và đang chạy trên máy tính của bạn.

- **Windows**: Tải từ [MongoDB Download Center](https://www.mongodb.com/try/download/community)
- **Mac**: `brew install mongodb-community`
- **Linux**: `sudo apt-get install mongodb`

Khởi động MongoDB:

```bash
# Windows
net start MongoDB

# Mac/Linux
sudo systemctl start mongod
```

## ⚙️ Cấu hình

File `.env` đã được tạo sẵn với các cấu hình mặc định:

```env
PORT=3000
MONGODB_URI=mongodb://localhost:27017/lab0809_restapi
JWT_SECRET=your_super_secret_jwt_key_change_this_in_production
JWT_EXPIRES_IN=7d
MAX_FILE_SIZE=5242880
UPLOAD_PATH=./uploads
```

**Lưu ý:** Đổi `JWT_SECRET` thành một chuỗi bí mật phức tạp trong môi trường production.

## 🚀 Chạy ứng dụng

### Development mode (với nodemon)

```bash
npm run dev
```

### Production mode

```bash
npm start
```

Server sẽ chạy tại: `http://localhost:3000`

## 📚 API Endpoints

### 🔐 Account (Authentication)

#### 1. Đăng ký tài khoản
```
POST /api/account/register
```

**Body:**
```json
{
  "email": "user@example.com",
  "password": "password123"
}
```

**Response:**
```json
{
  "success": true,
  "message": "Account registered successfully",
  "data": {
    "account": {
      "id": "...",
      "email": "user@example.com"
    },
    "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
  }
}
```

#### 2. Đăng nhập
```
POST /api/account/login
```

**Body:**
```json
{
  "email": "user@example.com",
  "password": "password123"
}
```

**Response:**
```json
{
  "success": true,
  "message": "Login successful",
  "data": {
    "account": {
      "id": "...",
      "email": "user@example.com"
    },
    "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
  }
}
```

---

### 📦 Products

#### 1. Lấy danh sách tất cả sản phẩm (Public)
```
GET /api/products
```

**Response:**
```json
{
  "success": true,
  "count": 2,
  "data": [
    {
      "_id": "...",
      "productCode": "PRD001",
      "productName": "Product 1",
      "price": 100000,
      "image": "1234567890-image.jpg",
      "description": "Description here",
      "createdAt": "...",
      "updatedAt": "..."
    }
  ]
}
```

#### 2. Lấy chi tiết sản phẩm (Public)
```
GET /api/products/:id
```

#### 3. Tạo sản phẩm mới (Protected - Require JWT) 🔒
```
POST /api/products
```

**Headers:**
```
Authorization: Bearer <your_jwt_token>
Content-Type: multipart/form-data
```

**Body (form-data):**
- `productCode` (text): Mã sản phẩm
- `productName` (text): Tên sản phẩm
- `price` (text): Giá sản phẩm
- `description` (text): Mô tả (optional)
- `image` (file): Hình ảnh (optional)

#### 4. Cập nhật sản phẩm (Protected - Require JWT) 🔒
```
PUT /api/products/:id
```

**Headers:**
```
Authorization: Bearer <your_jwt_token>
Content-Type: multipart/form-data
```

**Body (form-data):** Tương tự POST, nhưng tất cả fields đều optional

#### 5. Xóa sản phẩm (Protected - Require JWT) 🔒
```
DELETE /api/products/:id
```

**Headers:**
```
Authorization: Bearer <your_jwt_token>
```

---

### 🛒 Orders

#### 1. Lấy danh sách tất cả đơn hàng (Public)
```
GET /api/orders
```

**Response:**
```json
{
  "success": true,
  "count": 1,
  "data": [
    {
      "_id": "...",
      "orderCode": "ORD001",
      "totalPrice": 250000,
      "products": [
        {
          "productCode": "PRD001",
          "quantity": 2,
          "price": 100000
        },
        {
          "productCode": "PRD002",
          "quantity": 1,
          "price": 50000
        }
      ],
      "createdAt": "...",
      "updatedAt": "..."
    }
  ]
}
```

#### 2. Lấy chi tiết đơn hàng (Public)
```
GET /api/orders/:id
```

#### 3. Tạo đơn hàng mới (Protected - Require JWT) 🔒
```
POST /api/orders
```

**Headers:**
```
Authorization: Bearer <your_jwt_token>
Content-Type: application/json
```

**Body:**
```json
{
  "orderCode": "ORD001",
  "totalPrice": 250000,
  "products": [
    {
      "productCode": "PRD001",
      "quantity": 2,
      "price": 100000
    },
    {
      "productCode": "PRD002",
      "quantity": 1,
      "price": 50000
    }
  ]
}
```

#### 4. Cập nhật đơn hàng (Protected - Require JWT) 🔒
```
PUT /api/orders/:id
```

**Headers:** Tương tự POST
**Body:** Tương tự POST, nhưng tất cả fields đều optional

#### 5. Xóa đơn hàng (Protected - Require JWT) 🔒
```
DELETE /api/orders/:id
```

**Headers:**
```
Authorization: Bearer <your_jwt_token>
```

---

## 🔑 Xác thực (Authentication)

Các endpoint có đánh dấu 🔒 yêu cầu JWT token trong header:

```
Authorization: Bearer <your_jwt_token>
```

### Cách sử dụng:
1. Đăng ký/đăng nhập để nhận token
2. Thêm token vào header của các request cần xác thực
3. Token có thời hạn 7 ngày (cấu hình trong `.env`)

---

## 📁 Cấu trúc thư mục

```
52200151_Lab0809/
├── config/
│   └── database.js          # Cấu hình kết nối MongoDB
├── controllers/
│   ├── accountController.js # Xử lý logic account
│   ├── productController.js # Xử lý logic product
│   └── orderController.js   # Xử lý logic order
├── middlewares/
│   ├── auth.js             # JWT authentication middleware
│   ├── upload.js           # Multer file upload middleware
│   └── errorHandler.js     # Error handling middleware
├── models/
│   ├── Account.js          # Schema Account
│   ├── Product.js          # Schema Product
│   └── Order.js            # Schema Order
├── routes/
│   ├── accountRoutes.js    # Routes cho account
│   ├── productRoutes.js    # Routes cho product
│   └── orderRoutes.js      # Routes cho order
├── uploads/                # Thư mục lưu file upload
├── .env                    # Environment variables
├── .gitignore
├── package.json
├── server.js               # Entry point
└── README.md
```

---

## 🧪 Test API với Postman/Thunder Client

### 1. Đăng ký tài khoản
- Method: POST
- URL: `http://localhost:3000/api/account/register`
- Body (raw JSON):
```json
{
  "email": "test@example.com",
  "password": "123456"
}
```

### 2. Đăng nhập và lưu token
- Method: POST
- URL: `http://localhost:3000/api/account/login`
- Lưu lại `token` từ response

### 3. Tạo sản phẩm (cần token)
- Method: POST
- URL: `http://localhost:3000/api/products`
- Headers: `Authorization: Bearer <your_token>`
- Body (form-data):
  - productCode: PRD001
  - productName: Laptop Dell XPS
  - price: 25000000
  - description: Laptop cao cấp
  - image: [chọn file ảnh]

### 4. Tạo đơn hàng (cần token)
- Method: POST
- URL: `http://localhost:3000/api/orders`
- Headers: `Authorization: Bearer <your_token>`
- Body (raw JSON):
```json
{
  "orderCode": "ORD001",
  "totalPrice": 25000000,
  "products": [
    {
      "productCode": "PRD001",
      "quantity": 1,
      "price": 25000000
    }
  ]
}
```

---

## 🛡️ Security Features

- ✅ **Password Hashing**: Bcrypt với salt rounds = 10
- ✅ **JWT Authentication**: Token-based authentication
- ✅ **Rate Limiting**: 100 requests per 15 minutes per IP
- ✅ **File Upload Validation**: Chỉ cho phép image files
- ✅ **File Size Limit**: Maximum 5MB
- ✅ **Input Validation**: Express-validator cho tất cả inputs
- ✅ **CORS Protection**: Configured for cross-origin requests
- ✅ **Error Handling**: Centralized error handling

---

## 📝 Validation Rules

### Account
- Email: Required, valid email format
- Password: Required, minimum 6 characters

### Product
- productCode: Required, unique
- productName: Required
- price: Required, positive number
- image: Optional, max 5MB, image files only
- description: Optional

### Order
- orderCode: Required, unique
- totalPrice: Required, positive number
- products: Required, array with at least 1 item
  - productCode: Required
  - quantity: Required, minimum 1
  - price: Required, positive number

---

## 🐛 Error Handling

API trả về error responses với format:

```json
{
  "success": false,
  "message": "Error message here",
  "errors": ["Detailed error 1", "Detailed error 2"]
}
```

Common HTTP status codes:
- `200` - Success
- `201` - Created
- `400` - Bad Request (validation error)
- `401` - Unauthorized (missing/invalid token)
- `404` - Not Found
- `429` - Too Many Requests (rate limit exceeded)
- `500` - Internal Server Error

---

## 👨‍💻 Student Information

- **Student ID**: 52200151
- **Lab**: 8-9
- **Subject**: Web Application Development Using NodeJS

---

## 📄 License

ISC License - For educational purposes only.
