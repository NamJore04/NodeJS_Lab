# Quick Start Guide

## Bước 1: Khởi động MongoDB

Đảm bảo MongoDB đang chạy trên máy tính của bạn:

**Windows:**
```bash
net start MongoDB
```

**Mac/Linux:**
```bash
sudo systemctl start mongod
# hoặc
brew services start mongodb-community
```

## Bước 2: Cài đặt dependencies (đã hoàn thành)

```bash
npm install
```

## Bước 3: Chạy server

### Development mode (tự động reload khi có thay đổi):
```bash
npm run dev
```

### Production mode:
```bash
npm start
```

Server sẽ chạy tại: **http://localhost:3000**

## Bước 4: Test API

Bạn có thể test API bằng:
- **Postman** - Tải tại https://www.postman.com/
- **Thunder Client** - Extension trong VS Code
- **cURL** - Command line

## Sample Requests

### 1. Đăng ký tài khoản

```bash
curl -X POST http://localhost:3000/api/account/register \
  -H "Content-Type: application/json" \
  -d "{\"email\":\"test@example.com\",\"password\":\"123456\"}"
```

### 2. Đăng nhập

```bash
curl -X POST http://localhost:3000/api/account/login \
  -H "Content-Type: application/json" \
  -d "{\"email\":\"test@example.com\",\"password\":\"123456\"}"
```

**Lưu lại token từ response để sử dụng cho các request sau!**

### 3. Xem danh sách sản phẩm (không cần token)

```bash
curl http://localhost:3000/api/products
```

### 4. Tạo sản phẩm mới (cần token)

```bash
curl -X POST http://localhost:3000/api/products \
  -H "Authorization: Bearer YOUR_TOKEN_HERE" \
  -F "productCode=PRD001" \
  -F "productName=Laptop Dell XPS 15" \
  -F "price=25000000" \
  -F "description=Laptop cao cấp cho developer" \
  -F "image=@/path/to/your/image.jpg"
```

### 5. Tạo đơn hàng (cần token)

```bash
curl -X POST http://localhost:3000/api/orders \
  -H "Authorization: Bearer YOUR_TOKEN_HERE" \
  -H "Content-Type: application/json" \
  -d "{\"orderCode\":\"ORD001\",\"totalPrice\":25000000,\"products\":[{\"productCode\":\"PRD001\",\"quantity\":1,\"price\":25000000}]}"
```

## Troubleshooting

### Lỗi: MongoDB connection error

**Giải pháp:**
- Kiểm tra MongoDB đã được cài đặt và đang chạy
- Kiểm tra MONGODB_URI trong file `.env`

### Lỗi: Port 3000 already in use

**Giải pháp:**
- Đổi PORT trong file `.env` sang giá trị khác (ví dụ: 3001, 5000)
- Hoặc tắt ứng dụng đang sử dụng port 3000

### Lỗi: JWT token invalid

**Giải pháp:**
- Kiểm tra format header: `Authorization: Bearer <token>`
- Đảm bảo token chưa hết hạn (mặc định 7 ngày)
- Đăng nhập lại để lấy token mới

## Các endpoint quan trọng

- **API Documentation**: http://localhost:3000/
- **Uploaded Images**: http://localhost:3000/uploads/[filename]

## Next Steps

1. ✅ Test tất cả các endpoints
2. ✅ Thử upload hình ảnh cho sản phẩm
3. ✅ Test validation errors (gửi data không hợp lệ)
4. ✅ Test rate limiting (gửi >100 requests trong 15 phút)
5. ✅ Test authentication (thử access protected routes mà không có token)

Happy Coding! 🚀
