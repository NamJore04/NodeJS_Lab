// API Base URL
const API_URL = 'http://localhost:3000/api';

// Global state
let token = localStorage.getItem('token');
let currentUser = null;
let products = [];
let orders = [];
let editingProductId = null;
let editingOrderId = null;

// Initialize app
document.addEventListener('DOMContentLoaded', () => {
    if (token) {
        currentUser = JSON.parse(localStorage.getItem('user'));
        updateUIForLoggedInUser();
    }
    loadProducts();
    loadOrders();
});

// ==================== Authentication ====================

async function handleRegister(event) {
    event.preventDefault();
    const formData = new FormData(event.target);
    const data = {
        email: formData.get('email'),
        password: formData.get('password'),
        confirmPassword: formData.get('confirmPassword')
    };

    if (data.password !== data.confirmPassword) {
        showToast('Mật khẩu xác nhận không khớp!', 'error');
        return;
    }

    try {
        const response = await fetch(`${API_URL}/account/register`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ email: data.email, password: data.password })
        });

        const result = await response.json();

        if (result.success) {
            showToast('Đăng ký thành công! Vui lòng đăng nhập.', 'success');
            closeModal('registerModal');
            event.target.reset();
            showLoginModal();
        } else {
            showToast(result.message || 'Đăng ký thất bại!', 'error');
        }
    } catch (error) {
        console.error('Register error:', error);
        showToast('Có lỗi xảy ra khi đăng ký!', 'error');
    }
}

async function handleLogin(event) {
    event.preventDefault();
    const formData = new FormData(event.target);
    const data = {
        email: formData.get('email'),
        password: formData.get('password')
    };

    try {
        const response = await fetch(`${API_URL}/account/login`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(data)
        });

        const result = await response.json();

        if (result.success) {
            token = result.data.token;
            currentUser = { email: data.email };
            localStorage.setItem('token', token);
            localStorage.setItem('user', JSON.stringify(currentUser));
            
            updateUIForLoggedInUser();
            closeModal('loginModal');
            event.target.reset();
            showToast('Đăng nhập thành công!', 'success');
            
            // Reload data
            loadProducts();
            loadOrders();
        } else {
            showToast(result.message || 'Đăng nhập thất bại!', 'error');
        }
    } catch (error) {
        console.error('Login error:', error);
        showToast('Có lỗi xảy ra khi đăng nhập!', 'error');
    }
}

function handleLogout() {
    token = null;
    currentUser = null;
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    
    updateUIForLoggedOutUser();
    showToast('Đã đăng xuất!', 'info');
    
    // Reload data
    loadProducts();
    loadOrders();
}

function updateUIForLoggedInUser() {
    const userInfo = document.getElementById('userInfo');
    userInfo.innerHTML = `
        <span class="user-email"><i class="fas fa-user"></i> ${currentUser.email}</span>
        <button class="btn btn-secondary" onclick="handleLogout()">
            <i class="fas fa-sign-out-alt"></i> Đăng xuất
        </button>
    `;
    
    // Show protected buttons
    document.getElementById('btnAddProduct').style.display = 'inline-flex';
    document.getElementById('btnAddOrder').style.display = 'inline-flex';
}

function updateUIForLoggedOutUser() {
    const userInfo = document.getElementById('userInfo');
    userInfo.innerHTML = `
        <button class="btn btn-primary" onclick="showLoginModal()">
            <i class="fas fa-sign-in-alt"></i> Đăng nhập
        </button>
        <button class="btn btn-secondary" onclick="showRegisterModal()">
            <i class="fas fa-user-plus"></i> Đăng ký
        </button>
    `;
    
    // Hide protected buttons
    document.getElementById('btnAddProduct').style.display = 'none';
    document.getElementById('btnAddOrder').style.display = 'none';
}

// ==================== Products ====================

async function loadProducts() {
    const grid = document.getElementById('productsGrid');
    grid.innerHTML = '<div class="loading"><i class="fas fa-spinner fa-spin"></i> Đang tải...</div>';

    try {
        const response = await fetch(`${API_URL}/products`);
        const result = await response.json();

        if (result.success) {
            products = result.data;
            displayProducts(products);
        } else {
            grid.innerHTML = '<div class="empty-state"><i class="fas fa-box-open"></i><p>Không có sản phẩm nào</p></div>';
        }
    } catch (error) {
        console.error('Load products error:', error);
        grid.innerHTML = '<div class="empty-state"><i class="fas fa-exclamation-triangle"></i><p>Có lỗi xảy ra khi tải sản phẩm</p></div>';
    }
}

function displayProducts(productsToDisplay) {
    const grid = document.getElementById('productsGrid');
    
    if (productsToDisplay.length === 0) {
        grid.innerHTML = '<div class="empty-state"><i class="fas fa-box-open"></i><p>Không tìm thấy sản phẩm</p></div>';
        return;
    }

    grid.innerHTML = productsToDisplay.map(product => `
        <div class="product-card">
            <img src="${product.image ? API_URL.replace('/api', '') + '/' + product.image : 'https://via.placeholder.com/300x200?text=No+Image'}" 
                 alt="${product.productName}" 
                 class="product-image"
                 onerror="this.src='https://via.placeholder.com/300x200?text=No+Image'">
            <div class="product-body">
                <div class="product-code"><i class="fas fa-barcode"></i> ${product.productCode}</div>
                <h3 class="product-name">${product.productName}</h3>
                <div class="product-price">${formatCurrency(product.price)}</div>
                <p class="product-description">${product.description || 'Không có mô tả'}</p>
                <div class="product-actions">
                    <button class="btn btn-info btn-sm" onclick="viewProductDetail('${product._id}')">
                        <i class="fas fa-eye"></i> Chi tiết
                    </button>
                    ${token ? `
                        <button class="btn btn-warning btn-sm" onclick="editProduct('${product._id}')">
                            <i class="fas fa-edit"></i> Sửa
                        </button>
                        <button class="btn btn-danger btn-sm" onclick="deleteProduct('${product._id}')">
                            <i class="fas fa-trash"></i> Xóa
                        </button>
                    ` : ''}
                </div>
            </div>
        </div>
    `).join('');
}

function searchProducts() {
    const searchTerm = document.getElementById('searchProduct').value.toLowerCase();
    const filtered = products.filter(product =>
        product.productCode.toLowerCase().includes(searchTerm) ||
        product.productName.toLowerCase().includes(searchTerm) ||
        product.description.toLowerCase().includes(searchTerm)
    );
    displayProducts(filtered);
}

function showAddProductModal() {
    if (!token) {
        showToast('Vui lòng đăng nhập để thêm sản phẩm!', 'warning');
        return;
    }
    
    editingProductId = null;
    document.getElementById('productModalTitle').innerHTML = '<i class="fas fa-plus"></i> Thêm sản phẩm';
    document.getElementById('productForm').reset();
    document.getElementById('imagePreview').innerHTML = '';
    document.querySelector('input[name="productId"]').value = '';
    showModal('productModal');
}

async function editProduct(id) {
    editingProductId = id;
    const product = products.find(p => p._id === id);
    
    if (!product) return;
    
    document.getElementById('productModalTitle').innerHTML = '<i class="fas fa-edit"></i> Sửa sản phẩm';
    document.querySelector('input[name="productId"]').value = id;
    document.querySelector('input[name="productCode"]').value = product.productCode;
    document.querySelector('input[name="productName"]').value = product.productName;
    document.querySelector('input[name="price"]').value = product.price;
    document.querySelector('textarea[name="description"]').value = product.description || '';
    
    if (product.image) {
        document.getElementById('imagePreview').innerHTML = `
            <img src="${API_URL.replace('/api', '')}/${product.image}" alt="Preview">
        `;
    }
    
    showModal('productModal');
}

async function handleProductSubmit(event) {
    event.preventDefault();
    
    if (!token) {
        showToast('Vui lòng đăng nhập!', 'warning');
        return;
    }

    const formData = new FormData(event.target);
    const productId = formData.get('productId');
    
    // Remove productId from formData
    formData.delete('productId');

    try {
        const url = productId ? `${API_URL}/products/${productId}` : `${API_URL}/products`;
        const method = productId ? 'PUT' : 'POST';

        const response = await fetch(url, {
            method: method,
            headers: {
                'Authorization': `Bearer ${token}`
            },
            body: formData
        });

        const result = await response.json();

        if (result.success) {
            showToast(productId ? 'Cập nhật sản phẩm thành công!' : 'Thêm sản phẩm thành công!', 'success');
            closeModal('productModal');
            loadProducts();
        } else {
            showToast(result.message || 'Có lỗi xảy ra!', 'error');
        }
    } catch (error) {
        console.error('Product submit error:', error);
        showToast('Có lỗi xảy ra!', 'error');
    }
}

async function deleteProduct(id) {
    if (!token) {
        showToast('Vui lòng đăng nhập!', 'warning');
        return;
    }

    if (!confirm('Bạn có chắc chắn muốn xóa sản phẩm này?')) return;

    try {
        const response = await fetch(`${API_URL}/products/${id}`, {
            method: 'DELETE',
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });

        const result = await response.json();

        if (result.success) {
            showToast('Xóa sản phẩm thành công!', 'success');
            loadProducts();
        } else {
            showToast(result.message || 'Có lỗi xảy ra!', 'error');
        }
    } catch (error) {
        console.error('Delete product error:', error);
        showToast('Có lỗi xảy ra!', 'error');
    }
}

async function viewProductDetail(id) {
    const product = products.find(p => p._id === id);
    
    if (!product) return;

    const content = document.getElementById('productDetailContent');
    content.innerHTML = `
        <div class="product-detail">
            ${product.image ? `
                <img src="${API_URL.replace('/api', '')}/${product.image}" 
                     alt="${product.productName}" 
                     class="product-detail-image"
                     onerror="this.src='https://via.placeholder.com/400x300?text=No+Image'">
            ` : ''}
            <div class="product-detail-info">
                <p><strong><i class="fas fa-barcode"></i> Mã:</strong> ${product.productCode}</p>
                <p><strong><i class="fas fa-tag"></i> Tên:</strong> ${product.productName}</p>
                <p><strong><i class="fas fa-dollar-sign"></i> Giá:</strong> ${formatCurrency(product.price)}</p>
                <p><strong><i class="fas fa-align-left"></i> Mô tả:</strong></p>
                <p>${product.description || 'Không có mô tả'}</p>
            </div>
        </div>
    `;
    
    showModal('productDetailModal');
}

function previewImage(event) {
    const file = event.target.files[0];
    const preview = document.getElementById('imagePreview');
    
    if (file) {
        const reader = new FileReader();
        reader.onload = function(e) {
            preview.innerHTML = `<img src="${e.target.result}" alt="Preview">`;
        };
        reader.readAsDataURL(file);
    } else {
        preview.innerHTML = '';
    }
}

// ==================== Orders ====================

async function loadOrders() {
    const list = document.getElementById('ordersList');
    list.innerHTML = '<div class="loading"><i class="fas fa-spinner fa-spin"></i> Đang tải...</div>';

    try {
        const response = await fetch(`${API_URL}/orders`);
        const result = await response.json();

        if (result.success) {
            orders = result.data;
            displayOrders(orders);
        } else {
            list.innerHTML = '<div class="empty-state"><i class="fas fa-shopping-cart"></i><p>Không có đơn hàng nào</p></div>';
        }
    } catch (error) {
        console.error('Load orders error:', error);
        list.innerHTML = '<div class="empty-state"><i class="fas fa-exclamation-triangle"></i><p>Có lỗi xảy ra khi tải đơn hàng</p></div>';
    }
}

function displayOrders(ordersToDisplay) {
    const list = document.getElementById('ordersList');
    
    if (ordersToDisplay.length === 0) {
        list.innerHTML = '<div class="empty-state"><i class="fas fa-shopping-cart"></i><p>Không có đơn hàng nào</p></div>';
        return;
    }

    list.innerHTML = ordersToDisplay.map(order => `
        <div class="order-card">
            <div class="order-header">
                <div class="order-info">
                    <h3><i class="fas fa-receipt"></i> ${order.orderCode}</h3>
                    <div class="order-date">
                        <i class="fas fa-calendar"></i> ${formatDate(order.createdAt)}
                    </div>
                </div>
                <div class="order-total">
                    <div class="order-total-label">Tổng giá trị</div>
                    <div class="order-total-value">${formatCurrency(order.totalPrice)}</div>
                </div>
            </div>
            <div class="order-items">
                <strong><i class="fas fa-list"></i> Số sản phẩm: ${order.items.length}</strong>
            </div>
            <div class="order-actions">
                <button class="btn btn-info btn-sm" onclick="viewOrderDetail('${order._id}')">
                    <i class="fas fa-eye"></i> Chi tiết
                </button>
                ${token ? `
                    <button class="btn btn-warning btn-sm" onclick="editOrder('${order._id}')">
                        <i class="fas fa-edit"></i> Sửa
                    </button>
                    <button class="btn btn-danger btn-sm" onclick="deleteOrder('${order._id}')">
                        <i class="fas fa-trash"></i> Xóa
                    </button>
                ` : ''}
            </div>
        </div>
    `).join('');
}

function showAddOrderModal() {
    if (!token) {
        showToast('Vui lòng đăng nhập để tạo đơn hàng!', 'warning');
        return;
    }
    
    editingOrderId = null;
    document.getElementById('orderModalTitle').innerHTML = '<i class="fas fa-plus"></i> Tạo đơn hàng';
    document.getElementById('orderForm').reset();
    document.querySelector('input[name="orderId"]').value = '';
    document.getElementById('orderItemsList').innerHTML = '';
    addOrderItem();
    showModal('orderModal');
}

function addOrderItem() {
    const itemsList = document.getElementById('orderItemsList');
    const itemIndex = itemsList.children.length;
    
    const itemHTML = `
        <div class="order-item-form" data-index="${itemIndex}">
            <button type="button" class="btn btn-danger btn-sm remove-item-btn" onclick="removeOrderItem(${itemIndex})">
                <i class="fas fa-times"></i>
            </button>
            <div class="form-group">
                <label>Mã sản phẩm</label>
                <input type="text" name="items[${itemIndex}][productCode]" required placeholder="Nhập mã sản phẩm">
            </div>
            <div class="form-group">
                <label>Số lượng</label>
                <input type="number" name="items[${itemIndex}][quantity]" required min="1" value="1" placeholder="Số lượng">
            </div>
            <div class="form-group">
                <label>Giá</label>
                <input type="number" name="items[${itemIndex}][price]" required min="0" step="0.01" placeholder="Giá sản phẩm">
            </div>
        </div>
    `;
    
    itemsList.insertAdjacentHTML('beforeend', itemHTML);
}

function removeOrderItem(index) {
    const item = document.querySelector(`.order-item-form[data-index="${index}"]`);
    if (item) {
        item.remove();
    }
}

async function editOrder(id) {
    editingOrderId = id;
    const order = orders.find(o => o._id === id);
    
    if (!order) return;
    
    document.getElementById('orderModalTitle').innerHTML = '<i class="fas fa-edit"></i> Sửa đơn hàng';
    document.querySelector('input[name="orderId"]').value = id;
    document.querySelector('input[name="orderCode"]').value = order.orderCode;
    document.querySelector('input[name="totalPrice"]').value = order.totalPrice;
    
    const itemsList = document.getElementById('orderItemsList');
    itemsList.innerHTML = '';
    
    order.items.forEach((item, index) => {
        const itemHTML = `
            <div class="order-item-form" data-index="${index}">
                <button type="button" class="btn btn-danger btn-sm remove-item-btn" onclick="removeOrderItem(${index})">
                    <i class="fas fa-times"></i>
                </button>
                <div class="form-group">
                    <label>Mã sản phẩm</label>
                    <input type="text" name="items[${index}][productCode]" required value="${item.productCode}">
                </div>
                <div class="form-group">
                    <label>Số lượng</label>
                    <input type="number" name="items[${index}][quantity]" required min="1" value="${item.quantity}">
                </div>
                <div class="form-group">
                    <label>Giá</label>
                    <input type="number" name="items[${index}][price]" required min="0" step="0.01" value="${item.price}">
                </div>
            </div>
        `;
        itemsList.insertAdjacentHTML('beforeend', itemHTML);
    });
    
    showModal('orderModal');
}

async function handleOrderSubmit(event) {
    event.preventDefault();
    
    if (!token) {
        showToast('Vui lòng đăng nhập!', 'warning');
        return;
    }

    const formData = new FormData(event.target);
    const orderId = formData.get('orderId');
    
    // Build order data
    const orderData = {
        orderCode: formData.get('orderCode'),
        totalPrice: parseFloat(formData.get('totalPrice')),
        items: []
    };

    // Get all items
    const itemForms = document.querySelectorAll('.order-item-form');
    itemForms.forEach((form, index) => {
        const productCode = formData.get(`items[${index}][productCode]`);
        const quantity = formData.get(`items[${index}][quantity]`);
        const price = formData.get(`items[${index}][price]`);
        
        if (productCode && quantity && price) {
            orderData.items.push({
                productCode,
                quantity: parseInt(quantity),
                price: parseFloat(price)
            });
        }
    });

    try {
        const url = orderId ? `${API_URL}/orders/${orderId}` : `${API_URL}/orders`;
        const method = orderId ? 'PUT' : 'POST';

        const response = await fetch(url, {
            method: method,
            headers: {
                'Authorization': `Bearer ${token}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(orderData)
        });

        const result = await response.json();

        if (result.success) {
            showToast(orderId ? 'Cập nhật đơn hàng thành công!' : 'Tạo đơn hàng thành công!', 'success');
            closeModal('orderModal');
            loadOrders();
        } else {
            showToast(result.message || 'Có lỗi xảy ra!', 'error');
        }
    } catch (error) {
        console.error('Order submit error:', error);
        showToast('Có lỗi xảy ra!', 'error');
    }
}

async function deleteOrder(id) {
    if (!token) {
        showToast('Vui lòng đăng nhập!', 'warning');
        return;
    }

    if (!confirm('Bạn có chắc chắn muốn xóa đơn hàng này?')) return;

    try {
        const response = await fetch(`${API_URL}/orders/${id}`, {
            method: 'DELETE',
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });

        const result = await response.json();

        if (result.success) {
            showToast('Xóa đơn hàng thành công!', 'success');
            loadOrders();
        } else {
            showToast(result.message || 'Có lỗi xảy ra!', 'error');
        }
    } catch (error) {
        console.error('Delete order error:', error);
        showToast('Có lỗi xảy ra!', 'error');
    }
}

async function viewOrderDetail(id) {
    const order = orders.find(o => o._id === id);
    
    if (!order) return;

    const content = document.getElementById('orderDetailContent');
    content.innerHTML = `
        <div class="order-detail">
            <div class="order-detail-info">
                <p><strong><i class="fas fa-receipt"></i> Mã đơn hàng:</strong> ${order.orderCode}</p>
                <p><strong><i class="fas fa-calendar"></i> Ngày tạo:</strong> ${formatDate(order.createdAt)}</p>
                <p><strong><i class="fas fa-money-bill"></i> Tổng giá trị:</strong> <span style="color: var(--success-color); font-size: 1.2rem; font-weight: bold;">${formatCurrency(order.totalPrice)}</span></p>
            </div>
            <div class="order-detail-items">
                <h4><i class="fas fa-list"></i> Sản phẩm trong đơn hàng (${order.items.length})</h4>
                ${order.items.map((item, index) => `
                    <div class="order-detail-item">
                        <div><strong>Mã SP:</strong> ${item.productCode}</div>
                        <div><strong>SL:</strong> ${item.quantity}</div>
                        <div><strong>Giá:</strong> ${formatCurrency(item.price)}</div>
                        <div><strong>Thành tiền:</strong> ${formatCurrency(item.quantity * item.price)}</div>
                    </div>
                `).join('')}
            </div>
        </div>
    `;
    
    showModal('orderDetailModal');
}

// ==================== UI Helpers ====================

function showSection(section) {
    // Update nav
    document.querySelectorAll('.nav-item').forEach(item => {
        item.classList.remove('active');
    });
    event.target.classList.add('active');
    
    // Update sections
    document.querySelectorAll('.section').forEach(sec => {
        sec.classList.remove('active');
    });
    
    if (section === 'products') {
        document.getElementById('productsSection').classList.add('active');
    } else if (section === 'orders') {
        document.getElementById('ordersSection').classList.add('active');
    }
}

function showModal(modalId) {
    const modal = document.getElementById(modalId);
    modal.classList.add('show');
}

function closeModal(modalId) {
    const modal = document.getElementById(modalId);
    modal.classList.remove('show');
}

function showLoginModal() {
    showModal('loginModal');
}

function showRegisterModal() {
    showModal('registerModal');
}

function showToast(message, type = 'info') {
    const toast = document.getElementById('toast');
    toast.textContent = message;
    toast.className = `toast ${type} show`;
    
    setTimeout(() => {
        toast.classList.remove('show');
    }, 3000);
}

function formatCurrency(amount) {
    return new Intl.NumberFormat('vi-VN', {
        style: 'currency',
        currency: 'VND'
    }).format(amount);
}

function formatDate(dateString) {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('vi-VN', {
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
        hour: '2-digit',
        minute: '2-digit'
    }).format(date);
}

// Close modal when clicking outside
window.onclick = function(event) {
    if (event.target.classList.contains('modal')) {
        event.target.classList.remove('show');
    }
}
