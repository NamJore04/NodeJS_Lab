```

FACULTY OF INFORMATION TECHNOLOGY

```

\## DEPARTMENT OF SOFTWARE ENGINEERING



\## WEB APPLICATION DEVELOPMENT USING NODEJS - 502070



\# LAB SESSION 8- 9



```

By Mai Van Manh

```

OBJECTIVES



1\. Develop a Rest API using ExpressJS.

2\. Explore the concept of Cross-Origin Resource Sharing (CORS).

3\. Familiarize yourself with the concept of Json Web Token (JWT) and its application for

&nbsp;   user authentication.

4\. Store data in MongoDB using Mongoose.

5\. Learn about the concept of Routers in ExpressJS.

6\. Review the knowledge about the MVC architecture.



ASSIGNMENT DESCRIPTION



Construct a REST API for managing account information, product management, and orders.

Detailed information is as follows:



\- User accounts have details such as email and password.

\- Products include details like product code, product name, price, illustration image, and

&nbsp;   description.

\- Orders encompass information like order code, total selling price, and a list of products.

&nbsp;   Each element in the product list of an order contains information like product code,

&nbsp;   quantity, and price.



The REST API provides two endpoints, /products and /orders, supporting various HTTP

methods to perform functions like adding, updating, deleting, listing, and retrieving details of

products/orders. Additionally, there are /account/register and /account/login APIs to manage

account registration and login. Some API endpoints require users to be logged in to access.

Input parameters for all endpoints are in JSON format. Detailed descriptions of the API

endpoints are as follows:





```

FACULTY OF INFORMATION TECHNOLOGY

```

\## DEPARTMENT OF SOFTWARE ENGINEERING



\- \[http://localhost/api/account/register:](http://localhost/api/account/register:)

&nbsp;   o POST: Register a new account

\- \[http://localhost/api/account/login:](http://localhost/api/account/login:)

&nbsp;   o POST: User logs in

\- \[http://localhost/api/products:](http://localhost/api/products:)

&nbsp;   o GET: Retrieve a list of all products in the system

&nbsp;   o POST: Add a new product

\- \[http://localhost/api/products/{id}](http://localhost/api/products/{id})

&nbsp;   o GET: Retrieve detailed information of a product based on its ID

&nbsp;   o PUT: Update information of a product based on its ID

&nbsp;   o DELETE: Delete a product based on its ID

\- \[http://localhost/api/orders:](http://localhost/api/orders:)

&nbsp;   o GET: Retrieve a list of all orders.

&nbsp;   o POST: Add a new order.

\- \[http://localhost/api/orders/{id}:](http://localhost/api/orders/{id}:)

&nbsp;   o GET: Retrieve detailed information of an order based on its ID

&nbsp;   o PUT: Update information of an order based on its ID

&nbsp;   o DELETE: Delete an order based on its ID



For API endpoint methods with highlighted red, users need to log in to access.



OTHER REQUIREMENTS



\- All data related to accounts, products, and orders should be stored in MongoDB and

&nbsp;   accessed from NodeJS through the Mongoose modules.

\- Use Express Router to implement functionalities for separate routes (e.g.,

&nbsp;   AccountRouter, ProductRouter, OrderRouter).

\- Set up Cross-Origin Resource Sharing to allow any web client, even from different

&nbsp;   domains, to access and interact with the REST API.

\- Use bcrypt to hash passwords, and use JWT for user authentication.





```

FACULTY OF INFORMATION TECHNOLOGY

```

\## DEPARTMENT OF SOFTWARE ENGINEERING



\- Continue utilizing introduced modules from previous lessons in the exercises, such as:

&nbsp;   o Use express-form, express-validator for validating data from HTML forms.

&nbsp;   o Use multer to handle file uploads.

&nbsp;   o Use the rate-limiting feature in Express to prevent DDOS attacks.

\- Implement error handling mechanism and return appropriate error messages: for

&nbsp;   example, missing information, incorrect data format, oversized uploaded files, invalid

&nbsp;   endpoints, unsupported HTTP methods, etc.

