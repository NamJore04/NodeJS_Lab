const express = require('express');
const router = express.Router();
const { body } = require('express-validator');
const orderController = require('../controllers/orderController');
const authMiddleware = require('../middlewares/auth');

// Validation rules
const orderValidation = [
  body('orderCode')
    .notEmpty().withMessage('Order code is required')
    .trim(),
  body('totalPrice')
    .notEmpty().withMessage('Total price is required')
    .isFloat({ min: 0 }).withMessage('Total price must be a positive number'),
  body('products')
    .isArray({ min: 1 }).withMessage('Order must contain at least one product'),
  body('products.*.productCode')
    .notEmpty().withMessage('Product code is required'),
  body('products.*.quantity')
    .notEmpty().withMessage('Quantity is required')
    .isInt({ min: 1 }).withMessage('Quantity must be at least 1'),
  body('products.*.price')
    .notEmpty().withMessage('Price is required')
    .isFloat({ min: 0 }).withMessage('Price must be a positive number')
];

const orderUpdateValidation = [
  body('orderCode')
    .optional()
    .trim(),
  body('totalPrice')
    .optional()
    .isFloat({ min: 0 }).withMessage('Total price must be a positive number'),
  body('products')
    .optional()
    .isArray({ min: 1 }).withMessage('Order must contain at least one product'),
  body('products.*.productCode')
    .optional()
    .notEmpty().withMessage('Product code is required'),
  body('products.*.quantity')
    .optional()
    .isInt({ min: 1 }).withMessage('Quantity must be at least 1'),
  body('products.*.price')
    .optional()
    .isFloat({ min: 0 }).withMessage('Price must be a positive number')
];

// Public routes
router.get('/', orderController.getAllOrders);
router.get('/:id', orderController.getOrder);

// Protected routes (require authentication)
router.post('/', authMiddleware, orderValidation, orderController.createOrder);
router.put('/:id', authMiddleware, orderUpdateValidation, orderController.updateOrder);
router.delete('/:id', authMiddleware, orderController.deleteOrder);

module.exports = router;
