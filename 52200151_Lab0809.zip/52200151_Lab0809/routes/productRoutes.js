const express = require('express');
const router = express.Router();
const { body } = require('express-validator');
const productController = require('../controllers/productController');
const authMiddleware = require('../middlewares/auth');
const { upload, handleMulterError } = require('../middlewares/upload');

// Validation rules
const productValidation = [
  body('productCode')
    .notEmpty().withMessage('Product code is required')
    .trim(),
  body('productName')
    .notEmpty().withMessage('Product name is required')
    .trim(),
  body('price')
    .notEmpty().withMessage('Price is required')
    .isFloat({ min: 0 }).withMessage('Price must be a positive number')
];

const productUpdateValidation = [
  body('productCode')
    .optional()
    .trim(),
  body('productName')
    .optional()
    .trim(),
  body('price')
    .optional()
    .isFloat({ min: 0 }).withMessage('Price must be a positive number')
];

// Public routes
router.get('/', productController.getAllProducts);
router.get('/:id', productController.getProduct);

// Protected routes (require authentication)
router.post(
  '/',
  authMiddleware,
  upload.single('image'),
  productValidation,
  productController.createProduct
);

router.put(
  '/:id',
  authMiddleware,
  upload.single('image'),
  productUpdateValidation,
  productController.updateProduct
);

router.delete('/:id', authMiddleware, productController.deleteProduct);

module.exports = router;
