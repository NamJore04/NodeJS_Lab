require("dotenv").config();
const express = require("express");
const session = require("express-session")
const bodyParser = require("body-parser");
const path = require("path");
const multer = require("multer");

const app = express();
const PORT = process.env.PORT || 3000;


let products = [
    {
      id: 1,
      name: "Laptop",
      price: 1500,
      image: "/images/laptop.jpg",
      description: "Powerful laptop with 16GB RAM and 512GB SSD"
    },
    {
      id: 2,
      name: "Phone",
      price: 800,
      image: "/images/phone.jpg",
      description: "Smartphone with high-quality camera and OLED display"
    },
    {
      id: 3,
      name: "Tablet",
      price: 600,
      image: "/images/tablet.jpg",
      description: "Lightweight tablet for work and entertainment"
    }
];



// Cấu hình nơi lưu ảnh upload
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
      cb(null, path.join(__dirname, "public/images"));
    },
    filename: (req, file, cb) => {
      // Tên file = timestamp + tên gốc
      cb(null, Date.now() + "-" + file.originalname);
    }
});
  
const upload = multer({ storage });
  
  

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, "public"))); 

app.use(session({
    secret: "secret-key", // bạn có thể đổi key này
    resave: false,
    saveUninitialized: true
  }));

// Cấu hình EJS
app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));

// Middleware kiểm tra login
function requireLogin(req, res, next) {
    if (!req.session.user) {
      return res.redirect("/login");
    }
    next();
}

// Route mặc định

// Route hiển thị trang login
app.get("/login", (req, res) => {
    res.render("login", { error: null });
});

app.get("/", (req, res) => {
  res.send("Product Management App - Express is running!");
});

app.post("/login", (req, res) => {
    const { username, password } = req.body;
    if (username === process.env.ADMIN_USER && password === process.env.ADMIN_PASS) {
      req.session.user = username;
      return res.redirect("/home");
    }
    res.render("login", { error: "Invalid username or password!" });
});


app.get("/home", requireLogin, (req, res) => {
    const message = req.session.message;
    req.session.message = null; // clear sau khi dùng
    res.render("home", { products, user: req.session.user, message });
  });

app.get("/product/:id", requireLogin, (req, res) => {
    const id = parseInt(req.params.id);
    const product = products.find(p => p.id === id);
  
    if (!product) {
      return res.render("detail", { product: null });
    }
  
    res.render("detail", { product });
});

// Hiển thị form thêm sản phẩm
app.get("/add", requireLogin, (req, res) => {
    res.render("add", { error: null });
});
  
  // Xử lý thêm sản phẩm
  app.post("/add", requireLogin, upload.single("image"), (req, res) => {
    const { name, price, description } = req.body;
  
    if (!name || !price || !description || !req.file) {
      return res.render("add", { error: "Please fill in all fields and upload an image!" });
    }
  
    const newProduct = {
      id: products.length + 1,
      name,
      price: parseFloat(price),
      description,
      image: "/images/" + req.file.filename
    };
  
    products.push(newProduct);
  
    // Lưu message vào session để hiện toast ở homepage
    req.session.message = "Product added successfully!";
    res.redirect("/home");
});


// GET: Hiển thị form chỉnh sửa
app.get("/edit/:id", requireLogin, (req, res) => {
    const id = parseInt(req.params.id);
    const product = products.find(p => p.id === id);
  
    if (!product) {
      req.session.message = "Product not found!";
      return res.redirect("/home");
    }
  
    res.render("edit", { product, error: null });
});


// POST: Xử lý cập nhật
app.post("/edit/:id", requireLogin, upload.single("image"), (req, res) => {
    const id = parseInt(req.params.id);
    const product = products.find(p => p.id === id);
  
    if (!product) {
      req.session.message = "Product not found!";
      return res.redirect("/home");
    }
  
    const { name, price, description } = req.body;
  
    if (!name || !price || !description) {
      return res.render("edit", { product, error: "Please fill in all fields!" });
    }
  
    // Cập nhật dữ liệu
    product.name = name;
    product.price = parseFloat(price);
    product.description = description;
  
    // Nếu có upload ảnh mới thì cập nhật ảnh
    if (req.file) {
      product.image = "/images/" + req.file.filename;
    }
  
    req.session.message = "Product updated successfully!";
    res.redirect("/home");
  });
  

  app.post("/delete", requireLogin, (req, res) => {
    const { id } = req.body;
    const index = products.findIndex(p => p.id === parseInt(id));
  
    if (index === -1) {
      return res.status(404).json({ success: false, message: "Product not found" });
    }
  
    products.splice(index, 1);
    return res.json({ success: true, message: "Product deleted successfully" });
  });
  
  
  
  

app.get("/logout", (req, res) => {
    req.session.destroy(() => {
      res.redirect("/login");
    });
  });


// Chạy server
app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
