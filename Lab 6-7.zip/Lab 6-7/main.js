require('dotenv').config();
const express = require('express');
const session = require('express-session');
const MongoStore = require('connect-mongo');
const csurf = require('csurf');
const rateLimit = require('express-rate-limit');
const flash = require('connect-flash');
const path = require('path');
const connectDB = require('./config/database');

const app = express();
const PORT = process.env.PORT || 12346;

// Connect to MongoDB
connectDB();

// Session store
const sessionStore = MongoStore.create({
    mongoUrl: process.env.MONGODB_URI || 'mongodb://localhost:27017/file_manager_db',
    collectionName: 'sessions',
    ttl: 24 * 60 * 60 // 1 day in seconds
});

// Middleware setup
app.use(express.json());
app.use(express.urlencoded({ extended: false }));

// Session middleware
app.use(session({
    secret: process.env.SESSION_SECRET,
    store: sessionStore,
    resave: false,
    saveUninitialized: false,
    cookie: {
        maxAge: 24 * 60 * 60 * 1000, // 24 hours
        httpOnly: true,
        secure: process.env.NODE_ENV === 'production',
        sameSite: 'strict'
    }
}));

// Flash messages
app.use(flash());

// CSRF protection - Accept token from body, query, and headers
app.use(csurf({ 
    cookie: false,
    value: (req) => {
        // For JSON requests, check headers first
        if (req.headers['content-type']?.includes('application/json')) {
            return req.headers['x-csrf-token'] || 
                   req.headers['csrf-token'] ||
                   req.body?._csrf;
        }
        // For form submissions, check body first
        return req.body?._csrf || 
               req.query._csrf || 
               req.headers['x-csrf-token'] || 
               req.headers['csrf-token'];
    }
}));

// Rate limiter
const limiter = rateLimit({
    windowMs: parseInt(process.env.RATE_LIMIT_WINDOW) || 15 * 60 * 1000,
    max: parseInt(process.env.RATE_LIMIT_MAX) || 100,
    message: 'Too many requests from this IP, please try again later.'
});
app.use(limiter);

// View engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Static files
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));
app.use(express.static(path.join(__dirname, 'public')));

// Make user and csrfToken available in all views
app.use((req, res, next) => {
    res.locals.user = req.session?.user || null;
    res.locals.csrfToken = req.csrfToken();
    next();
});

// Routes
app.use('/account', require('./routers/AccountRouter'));
app.use('/', require('./routers/FileRouter'));

// 404 handler
app.use((req, res) => {
    res.status(404).render('error', {
        code: 404,
        message: 'Page Not Found'
    });
});

// Error handler
app.use((err, req, res, next) => {
    console.error('Error:', err);
    
    if (err.code === 'EBADCSRFTOKEN') {
        return res.status(403).render('error', {
            code: 403,
            message: 'Invalid CSRF token'
        });
    }

    res.status(500).render('error', {
        code: 500,
        message: process.env.NODE_ENV === 'development' ? err.message : 'Internal Server Error'
    });
});

// Start server
app.listen(PORT, () => {
    console.log(`🚀 Server running at http://localhost:${PORT}`);
    console.log(`📁 Environment: ${process.env.NODE_ENV || 'development'}`);
    console.log(`🗄️  Database: MongoDB`);
});

