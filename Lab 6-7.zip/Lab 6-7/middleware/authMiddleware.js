const authMiddleware = (req, res, next) => {
    if (!req.session || !req.session.user) {
        return res.redirect('/account/login');
    }
    res.locals.user = req.session.user;
    next();
};

const guestMiddleware = (req, res, next) => {
    if (req.session && req.session.user) {
        return res.redirect('/');
    }
    next();
};

module.exports = { authMiddleware, guestMiddleware };
