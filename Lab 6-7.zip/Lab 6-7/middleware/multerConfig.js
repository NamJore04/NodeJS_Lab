const multer = require('multer');
const path = require('path');
const fs = require('fs');

const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        if (!req.session || !req.session.user) {
            return cb(new Error('Unauthorized'));
        }
        
        // Get current path from query string
        const currentPath = req.query.path || '';
        const uploadDir = path.join(
            __dirname, 
            '../uploads', 
            req.session.user.id.toString(),
            currentPath
        );
        
        // Create directory if not exists
        if (!fs.existsSync(uploadDir)) {
            fs.mkdirSync(uploadDir, { recursive: true });
        }
        
        cb(null, uploadDir);
    },
    filename: (req, file, cb) => {
        const ext = path.extname(file.originalname);
        const name = path.basename(file.originalname, ext);
        const safeName = name.replace(/[^a-zA-Z0-9_-]/g, '_');
        cb(null, `${safeName}-${Date.now()}${ext}`);
    }
});

const fileFilter = (req, file, cb) => {
    const blockedExts = ['.exe', '.msi', '.sh', '.bat', '.cmd'];
    const ext = path.extname(file.originalname).toLowerCase();
    
    if (blockedExts.includes(ext)) {
        return cb(new Error('File type not allowed'), false);
    }
    cb(null, true);
};

const upload = multer({
    storage,
    fileFilter,
    limits: {
        fileSize: parseInt(process.env.UPLOAD_MAX_SIZE) || 20 * 1024 * 1024 // 20MB
    }
});

module.exports = upload;
