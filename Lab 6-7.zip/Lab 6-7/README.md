# File Manager Web Application

A full-featured file management web application built with Node.js, Express, and MySQL.

## Features

✅ **Account Management**
- User registration with email validation
- Secure login with bcrypt password hashing
- Session-based authentication
- CSRF token protection

✅ **File Management**
- Upload files with progress bar
- Create folders
- Rename files and folders
- Delete files and folders
- Download files and folders (folders as zip)
- Real-time search
- Breadcrumb navigation

✅ **Security**
- CSRF protection on all forms
- Password hashing with bcrypt
- Session security (httpOnly, sameSite)
- Rate limiting to prevent DDOS
- File type validation
- Path traversal protection

## Tech Stack

- **Backend**: Node.js 16+, Express 4.18
- **Database**: MongoDB with Mongoose ODM
- **View Engine**: EJS 3.1
- **Frontend**: Bootstrap 4.5, jQuery 3.5, Font Awesome 5.3
- **Security**: bcrypt, csurf, express-validator, express-rate-limit
- **File Handling**: multer, archiver

## Setup Instructions

### 1. Prerequisites
- Node.js 16 or higher
- MongoDB 5 or higher (running locally or MongoDB Atlas)
- npm or yarn

### 2. Install Dependencies
```bash
npm install
```

### 3. Configure Environment
Create a `.env` file in the project root:
```env
NODE_ENV=development
PORT=12346

# MongoDB Connection
MONGODB_URI=mongodb://localhost:27017/file_manager_db
# For MongoDB Atlas use:
# MONGODB_URI=mongodb+srv://username:password@cluster.mongodb.net/file_manager_db

SESSION_SECRET=your-secret-key-change-this

UPLOAD_MAX_SIZE=20971520
UPLOAD_DIR=./uploads

RATE_LIMIT_WINDOW=900000
RATE_LIMIT_MAX=100
```

### 4. Start MongoDB
```bash
# If using local MongoDB
mongod

# Or use MongoDB Atlas (cloud) - update MONGODB_URI in .env
```

### 5. Create Upload Directory
```bash
mkdir uploads
```

### 6. Start Server
```bash
# Development (with auto-reload)
npm run dev

# Production
npm start
```

Server will run at: http://localhost:12346

**Note**: MongoDB collections will be created automatically when first user registers.

## Project Structure

```
Lab 6-7/
├── config/
│   └── database.js          # MongoDB connection config
├── middleware/
│   ├── authMiddleware.js    # Auth & guest middleware
│   └── multerConfig.js      # File upload config
├── models/
│   └── Account.js           # User account Mongoose schema
├── routers/
│   ├── AccountRouter.js     # Auth routes (login, register)
│   └── FileRouter.js        # File management routes
├── views/
│   ├── login.ejs            # Login page
│   ├── register.ejs         # Registration page
│   ├── index.ejs            # File manager UI
│   └── error.ejs            # Error page
├── uploads/                 # User file storage
├── .env                     # Environment variables
├── main.js                  # Entry point
├── package.json             # Dependencies
└── README.md                # This file
```

## API Endpoints

### Account Management
- `GET /account/login` - Login page
- `POST /account/login` - Login handler
- `GET /account/register` - Registration page
- `POST /account/register` - Registration handler
- `GET /account/logout` - Logout

### File Management (Protected)
- `GET /` - File manager home
- `GET /api/files` - List files (JSON)
- `POST /api/files/upload` - Upload file
- `POST /api/files/mkdir` - Create folder
- `POST /api/files/rename` - Rename file/folder
- `DELETE /api/files` - Delete file/folder
- `GET /api/files/download` - Download file/folder
- `GET /api/files/search` - Search files

## Usage

### Register Account
1. Navigate to http://localhost:12346/account/register
2. Fill in fullname, email, password
3. Click "Register"

### Login
1. Navigate to http://localhost:12346/account/login
2. Enter email and password
3. Click "Login"

### Manage Files
- **Upload**: Click "Choose file", select file, click "Upload"
- **Create Folder**: Click "New folder", enter name, click "Create"
- **Rename**: Click edit icon, enter new name, click "Save"
- **Delete**: Click trash icon, confirm deletion
- **Download**: Click download icon
- **Search**: Type in search box for real-time filtering
- **Navigate**: Click folder name to open, use breadcrumb to go back

## Security Features

1. **Password Security**: bcrypt hashing with salt rounds 10
2. **CSRF Protection**: CSRF tokens in all forms
3. **Session Security**: httpOnly, secure, sameSite cookies
4. **Rate Limiting**: 100 requests per 15 minutes per IP
5. **Input Validation**: express-validator on all inputs
6. **File Security**: File type validation, size limits, isolated storage
7. **Path Security**: Prevent directory traversal attacks

## Troubleshooting

### Database Connection Failed
- Ensure MongoDB is running: `mongod` or check MongoDB service
- Check MONGODB_URI in `.env`
- For MongoDB Atlas, check network access and whitelist your IP

### CSRF Token Invalid
- Clear browser cookies
- Restart server

### File Upload Failed
- Check `uploads/` directory exists and is writable
- Verify file size < 20MB
- Check file type is not .exe, .msi, .sh

### Port Already in Use
- Change PORT in `.env`
- Or kill process: `netstat -ano | findstr :12346` (Windows)

## License

ISC

## Author

Lab 6-7 - Web Application Development using Node.js
