const mongoose = require('mongoose');

const accountSchema = new mongoose.Schema({
    fullname: {
        type: String,
        required: [true, 'Fullname is required'],
        trim: true
    },
    email: {
        type: String,
        required: [true, 'Email is required'],
        unique: true,
        lowercase: true,
        trim: true,
        match: [/^\S+@\S+\.\S+$/, 'Please provide a valid email']
    },
    password: {
        type: String,
        required: [true, 'Password is required'],
        minlength: [6, 'Password must be at least 6 characters']
    }
}, {
    timestamps: true, // Adds createdAt and updatedAt
    collection: 'accounts'
});

// Index for faster email lookups
accountSchema.index({ email: 1 });

const Account = mongoose.model('Account', accountSchema);

module.exports = Account;
