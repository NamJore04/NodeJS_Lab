/**
 * MongoDB Indexes Setup Script
 * Run this file to create optimal indexes for the application
 * Usage: node db-indexes.js
 */

require('dotenv').config();
const mongoose = require('mongoose');

async function createIndexes() {
    try {
        // Connect to MongoDB
        await mongoose.connect(process.env.MONGODB_URI);
        console.log('✓ Connected to MongoDB');

        // Get database
        const db = mongoose.connection.db;

        // Create indexes for accounts collection
        const accountsCollection = db.collection('accounts');
        
        // Email index (unique, case-insensitive)
        await accountsCollection.createIndex(
            { email: 1 }, 
            { 
                unique: true,
                name: 'email_unique_index'
            }
        );
        console.log('✓ Created unique index on accounts.email');

        // Created at index for sorting
        await accountsCollection.createIndex(
            { createdAt: -1 },
            { name: 'created_at_index' }
        );
        console.log('✓ Created index on accounts.createdAt');

        // Create indexes for sessions collection
        const sessionsCollection = db.collection('sessions');
        
        // TTL index for automatic session cleanup
        await sessionsCollection.createIndex(
            { expires: 1 },
            { 
                expireAfterSeconds: 0,
                name: 'session_ttl_index'
            }
        );
        console.log('✓ Created TTL index on sessions.expires');

        console.log('\n✓ All indexes created successfully!');
        
        // List all indexes
        console.log('\nCurrent indexes:');
        console.log('Accounts:', await accountsCollection.indexes());
        console.log('Sessions:', await sessionsCollection.indexes());

    } catch (error) {
        console.error('✗ Error creating indexes:', error.message);
    } finally {
        await mongoose.connection.close();
        console.log('\n✓ Connection closed');
    }
}

createIndexes();
