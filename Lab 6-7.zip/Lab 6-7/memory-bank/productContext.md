# Product Context: Why This App & How It Works

## Problem Statement
Students need to:
1. Learn secure web authentication (bcrypt, sessions, CSRF)
2. Master file system operations in Node.js (fs module)
3. Combine server-side REST APIs with client-side AJAX
4. Implement streaming downloads and progress tracking
5. Connect to MongoDB databases with ODM (Mongoose)

This project consolidates **all these concepts into one real-world use case**: a personal file manager.

## User Stories & Expected Experience

### User: Student/Developer
**As a** student user  
**I want to** upload, organize, and download my files securely  
**So that** I can learn full-stack web development concepts in a practical way

**Workflows:**
1. **Sign up**: Register with name, email, password → Stored hashed in MongoDB
2. **Log in**: Email/password auth → Session cookie stored, redirected to home
3. **Browse files**: Click folders → See subfolder contents, breadcrumb trail shows path
4. **Upload**: Select file → See progress bar → File appears in list (no page reload)
5. **Manage**: Right-click or button click → Rename, delete (with confirm dialog)
6. **Download**: Single file → Direct download; Folder → Zip archive created, auto-deleted after download
7. **Search**: Type keyword → List filters in real-time to show matches
8. **Log out**: Destroy session → Redirected to login

## Technical Requirements (from Lab Spec)

### Account Management
- **Registration**: Capture fullname, email, password, confirm password
- **Storage**: MongoDB collection with _id, fullname, email, password (hashed), createdAt, updatedAt
- **Hashing**: Use bcrypt (salt rounds 10+) before insert
- **Validation**: Email format, password min 6 chars, matching confirm password
- **CSRF**: Hidden token in form, validated on POST /account/register

### Login & Sessions
- **Auth**: Username (or email) + password via bcrypt.compare()
- **Session**: On success, set `req.session.user = {id, fullname, email}`
- **Cookie**: Signed session cookie with httpOnly, secure flags
- **Auto-redirect**: 
  - Not logged in → Access / → Redirect to /account/login
  - Already logged in → Access /account/login or /account/register → Redirect to /

### File Management (Homepage `/`)
- **List**: Show folders (blue folder icon) first, then files with type icons, size, last-modified date
- **Upload**: Multipart form, multer middleware, progress bar with XHR/fetch
- **Create folder**: Modal dialog → POST /api/files/mkdir
- **Rename**: Edit icon → Modal input → POST /api/files/rename
- **Delete**: Trash icon → Confirm dialog → DELETE /api/files
- **Download**: File icon → GET /api/files/download?path=... (direct file or zip if folder)
- **Search**: Text input → Real-time filter in table (client-side or server-side)
- **Navigate**: Click folder name → Breadcrumb → Click parent to go up

### Security & Performance
- **CSRF**: csurf middleware on all state-changing endpoints
- **Rate-limit**: express-rate-limit to prevent DDOS (e.g., 100 req/min per IP)
- **Validation**: express-validator on all inputs
- **Flash messages**: Notify user on errors/success
- **Throttle downloads**: Optional stream throttle for large files
- **Path traversal protection**: Restrict file access to user's directory only
- **404 handling**: Unknown routes → /error with "404 Not Found" page

## User Interface Design (Bootstrap 4.5)
- **Color scheme**: Bootstrap secondary (gray) header, light body, primary blue for folders
- **Responsive**: Works on desktop (tested), mobile-friendly
- **Icons**: Font Awesome 5.3 (folder, file, download, edit, trash, search, upload)
- **Modals**: Bootstrap modals for confirm delete, rename input, new folder
- **Buttons**: Light border buttons for actions, success (green) for upload/confirm

## Data Flow Diagram
```
Client Browser
    ↓
Frontend (EJS + jQuery/Fetch)
    ↓
    ├─→ /account/* (AccountRouter)
    │    ├─ GET /login → render login.ejs
    │    ├─ GET /register → render register.ejs
    │    ├─ POST /register → validate, bcrypt hash, insert into DB → redirect /
    │    └─ POST /login → compare password, set session → redirect /
    │
    └─→ / (FileRouter - protected)
         ├─ GET / → list files for session.user.id → render index.ejs
         ├─ GET /api/files → JSON list of files in current path
         ├─ POST /api/files/upload → multer save → return file info
         ├─ POST /api/files/mkdir → create folder
         ├─ POST /api/files/rename → rename file
         ├─ DELETE /api/files → delete file
         ├─ GET /api/files/download → stream file or zip folder
         └─ GET /api/files/search → filter by keyword
    ↓
Express Backend
    ├─ Session middleware (express-session + session store)
    ├─ CSRF middleware (csurf)
    ├─ Auth middleware (check req.session.user)
    ├─ Multer config (destination, file size, allowed types)
    └─ Rate limiter (100 req/min per IP)
    ↓
MySQL Database (Sequelize ORM)
    ├─ Account table
    └─ File metadata table (if tracking DB records, else use fs only)
    ↓
File System
    └─ /uploads/{userId}/* (actual files stored on disk)
```

## Success Metrics
1. **Functionality**: All 9 core features working without bugs
2. **Security**: CSRF tokens validated, passwords hashed, sessions secure
3. **UX**: No page reloads for file ops, progress bars visible, dialogs confirm
4. **Performance**: Upload/download < 5s for typical files, search instant
5. **Code Quality**: Separate routers (AccountRouter, FileRouter), DRY middleware
