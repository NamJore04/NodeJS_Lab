# System Patterns: Architecture, Design Decisions & Technical Patterns

## High-Level Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                    Client Layer (Browser)                    │
│  EJS Templates (login.ejs, register.ejs, index.ejs)          │
│  + jQuery + Fetch API + Bootstrap Modals                     │
└─────────────────────────────────────────────────────────────┘
                            ↕ HTTP/AJAX
┌─────────────────────────────────────────────────────────────┐
│                    Express.js Server                          │
│  ├─ Middleware Stack:                                        │
│  │  ├─ express.urlencoded() for form parsing                 │
│  │  ├─ express-session for cookies                           │
│  │  ├─ csurf for CSRF tokens                                 │
│  │  ├─ Rate limiter                                          │
│  │  ├─ Auth middleware (check session)                       │
│  │  └─ Custom error handler                                  │
│  │                                                            │
│  ├─ Routers (separation of concerns):                        │
│  │  ├─ AccountRouter → /account/* (register, login)          │
│  │  └─ FileRouter → /api/files/* (file operations)           │
│  │                                                            │
│  └─ Express.static('views') → serve static files             │
└─────────────────────────────────────────────────────────────┘
                            ↕
┌─────────────────────────────────────────────────────────────┐
│                    Data Layer                                 │
│  ├─ MongoDB (Mongoose ODM)                                    │
│  │  ├─ accounts collection (_id, fullname, email, password)  │
│  │  └─ sessions collection (session data via MongoStore)     │
│  │                                                            │
│  └─ File System (fs module)                                  │
│     └─ /uploads/{userId}/* (actual files on disk)            │
└─────────────────────────────────────────────────────────────┘
```

## Router Separation Pattern

### AccountRouter (`routers/AccountRouter.js`)
**Responsibility**: User authentication (register, login, logout)

```javascript
// Endpoints:
GET  /account/login          → Render login form
GET  /account/register       → Render register form
POST /account/register       → Validate, hash, insert user (MongoDB), redirect
POST /account/login          → Validate credentials, set session, redirect
GET  /account/logout         → Destroy session, redirect login

// Middleware:
- express.urlencoded()       → Parse form data
- csurf for register/login   → CSRF protection
- bcrypt.hash() on password  → Hash before insert
- bcrypt.compare() on login  → Verify password
- Mongoose queries           → Account.findOne(), Account.create()
```

### FileRouter (`routers/FileRouter.js`)
**Responsibility**: File/folder operations (list, upload, rename, delete, download, search)

```javascript
// Endpoints (all protected by auth middleware):
GET  /api/files              → List files in current path (JSON)
GET  /api/files/download     → Stream file or zip folder
POST /api/files/upload       → Multer save, return file info
POST /api/files/mkdir        → Create new folder
POST /api/files/rename       → Rename file/folder
DELETE /api/files            → Delete file/folder

// Middleware:
- Auth check (session.user)  → Verify logged-in
- multer                      → Handle multipart file upload
- csurf                       → CSRF protection on POST/DELETE
- express-validator          → Validate inputs
- Rate limiter               → Prevent abuse
```

## Authentication Pattern

```
Registration Flow:
┌──────────────────────────────────┐
│ User submits register form        │
├──────────────────────────────────┤
│ 1. CSRF token validated           │
│ 2. Input validated (express-validator) │
│ 3. Email uniqueness checked (Mongoose) │
│ 4. Password hashed (bcrypt)       │
│ 5. User inserted into MongoDB     │
│ 6. Session created (user._id stored) │
│ 7. Redirect to / (home)           │
└──────────────────────────────────┘

Login Flow:
┌──────────────────────────────────┐
│ User submits login form           │
├──────────────────────────────────┤
│ 1. CSRF token validated           │
│ 2. User lookup by email (Mongoose) │
│ 3. bcrypt.compare() check         │
│ 4. req.session.user = {id: _id.toString(), ...} │
│ 5. Redirect to / (home)           │
└──────────────────────────────────┘

Session Check (Auth Middleware):
┌──────────────────────────────────┐
│ Request to protected endpoint     │
├──────────────────────────────────┤
│ 1. Check req.session.user         │
│ 2. If missing → redirect /account/login │
│ 3. If present → allow & inject user info │
└──────────────────────────────────┘
```

## File Operation Patterns

### Upload Pattern (with Progress)
```
Frontend:
1. User selects file → File input change event
2. Create FormData with file
3. XHR or Fetch with onprogress handler
4. Update progress bar: event.loaded / event.total * 100
5. On success → Add row to file table (AJAX)

Backend (multer):
1. Configure destination: /uploads/{userId}/{filename}
2. File size limit: 20MB
3. Blocked types: .exe, .msi, .sh
4. On success → Return {success: true, file: {...}}
5. On error → Return {success: false, error: "..."}
```

### Download Pattern (Single File)
```
GET /api/files/download?path=document.pdf

Backend:
1. Sanitize path (prevent ../ traversal)
2. Check file belongs to user
3. Set headers:
   - Content-Type: application/pdf
   - Content-Disposition: attachment; filename="document.pdf"
4. Stream file to client
5. Client receives download
```

### Download Pattern (Folder as Zip)
```
GET /api/files/download?path=MyFolder&format=zip

Backend:
1. Recursively collect all files in folder
2. Create archiver stream
3. Set headers:
   - Content-Type: application/zip
   - Content-Disposition: attachment; filename="MyFolder.zip"
4. Stream zip to client
5. After response ends → Delete temp zip file
```

### Search Pattern
```
Frontend (Real-time filtering):
1. User types in search input → keyup event
2. AJAX POST /api/files/search?q={keyword}
3. Backend returns filtered list
4. Update table rows (show matches only)

Backend:
- Simple: filename.includes(keyword)
- Advanced: regex, case-insensitive, partial matches
```

## Data Validation Pattern

**Entry points that require validation:**
- POST /account/register: name, email, password, confirmPassword
- POST /account/login: email/username, password
- POST /api/files/upload: file size, MIME type, filename
- POST /api/files/mkdir: folder name (no special chars)
- POST /api/files/rename: new name (no ../, valid chars)
- DELETE /api/files: path (no traversal)

**Validation approach:**
```javascript
const { body, validationResult } = require('express-validator');

app.post('/register',
  body('email').isEmail(),
  body('password').isLength({min: 6}),
  body('name').notEmpty(),
  (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json({errors: errors.array()});
    // Process valid input
  }
);
```

## CSRF Protection Pattern

```
1. Middleware setup:
   app.use(csurf({ cookie: false })); // Use session storage

2. On GET /account/login or GET /account/register:
   - Generate token: req.csrfToken()
   - Inject into template: <input type="hidden" name="_csrf" value="<%= csrfToken %>">

3. On POST /account/register:
   - csurf middleware auto-validates _csrf field
   - If invalid → 403 Forbidden
   - If valid → Continue to handler

4. For AJAX requests (fetch):
   - Include CSRF token in fetch headers: 'X-CSRF-Token': req.csrfToken()
   - Or in FormData: formData.append('_csrf', token)
```

## Session Management Pattern

```
Middleware stack (main.js):
1. app.use(express.urlencoded())
2. app.use(express.json())
3. app.use(session({
     secret: 'your-secret-key',
     resave: false,
     saveUninitialized: true,
     cookie: {secure: false, httpOnly: true, sameSite: 'strict'}
   }))
4. app.use(csurf())
5. app.use(authMiddleware) // Custom check for protected routes

Auth middleware (auto-attached to FileRouter):
const authMiddleware = (req, res, next) => {
  if (!req.session.user) return res.redirect('/account/login');
  res.locals.user = req.session.user;
  next();
};
```

## Error Handling Pattern

```
404 Not Found:
- Route not matched → app.get('*', (req, res) => res.render('error', {code: 404}))

Auth errors (401):
- Missing session → redirect /account/login

CSRF errors (403):
- Token validation failed → render error page

Validation errors (400):
- Return JSON: {success: false, errors: [{field: 'email', msg: '...'}]}

Server errors (500):
- Try-catch in async handlers
- Return JSON: {success: false, error: 'Server error'}
```

## Performance Optimizations

1. **Connection Pooling**: Sequelize auto-pools MySQL connections
2. **Stream Downloads**: Use fs.createReadStream() for large files (not load in memory)
3. **Zip Streaming**: archiver streams zip (not buffer entire zip in memory)
4. **Rate Limiting**: 100 req/min per IP to prevent DDOS
5. **Session Store**: Use MySQL session store (not memory) for scalability
6. **Static Files**: app.use(express.static('public')) for CSS, JS (CDN-hosted in this case)

## Key Design Decisions

| Decision | Rationale |
|----------|-----------|
| Separate AccountRouter & FileRouter | Modularity, easier testing |
| EJS for templates | Support dynamic CSRF tokens in forms |
| Sequelize ORM | Type-safe, migrations, better than raw SQL |
| Multer for upload | Standard, battle-tested, middleware pattern |
| fs module for storage | Simplicity, user files isolated by userId folder |
| AJAX for file ops | No page reloads, better UX, progress tracking |
| Session-based auth | Simpler than JWT for traditional web apps |
| Bootstrap UI | Responsive, minimal CSS needed, familiar |
