# Project Brief: File Management Web Application

## Project Name
**Lab 6-7: File Management Web App** (Web Application Development using Node.js - 502070)

## Core Objective
Build a **secure, full-stack file management web application** using Express.js that allows authenticated users to:
- Register and login with password hashing (bcrypt)
- Upload, list, search, rename, and delete files/folders
- Download files and folders (as zip archives)
- Navigate folder hierarchies with breadcrumb navigation
- Perform all file operations via AJAX/fetch without page reloads

## Key Constraints
- **Backend**: Express.js + Node.js on port 12346
- **Database**: MongoDB with Mongoose ODM
- **Security**: CSRF tokens, bcrypt password hashing, session/cookie auth
- **File Handling**: multer for uploads, fs module for file ops, archiver for zip downloads
- **Frontend**: EJS templates, Bootstrap 4.5, jQuery 3.5, Font Awesome 5.3
- **Client-Server**: AJAX/fetch REST API, progress bars, confirm dialogs
- **Performance**: Throttle file downloads, rate-limit endpoints to prevent DDOS

## Success Criteria
1. ✅ Account registration/login with MongoDB persistence
2. ✅ Session-based authentication with auto-redirect
3. ✅ File/folder CRUD operations (create, rename, delete, list)
4. ✅ File upload with progress bar display
5. ✅ File/folder download (folders as zip)
6. ✅ Search by filename in current folder
7. ✅ Breadcrumb navigation between folders
8. ✅ CSRF protection on all forms
9. ✅ 404 error page for invalid routes

## Scope (In/Out)
**In Scope:**
- Account management (register, login, logout)
- File management (CRUD, search, download, upload)
- Session & cookie management
- CSRF & password security

**Out of Scope:**
- User profile updates (mentioned but low priority)
- Collaborative features (sharing, permissions)
- Real-time file sync

## Tech Stack Summary
- **Runtime**: Node.js 16+
- **Framework**: Express.js 4.18
- **ODM**: Mongoose 8.0
- **Database**: MongoDB 8+
- **File Upload**: multer 1.4
- **Password**: bcrypt 5.1
- **Validation**: express-validator 7.0
- **View Engine**: EJS 3.1
- **Session Store**: connect-mongo 5.1
- **Dev Tools**: nodemon 3.0

## Project Structure
```
Lab 6-7/
├── main.js                 # Entry point
├── package.json            # Dependencies
├── config/
│   └── database.js         # Mongoose connection
├── models/
│   └── Account.js          # Mongoose Account schema
├── routers/
│   ├── AccountRouter.js    # Auth routes (login, register, logout)
│   └── FileRouter.js       # File management routes
├── middleware/
│   ├── authMiddleware.js   # Session check middleware
│   └── multerConfig.js     # File upload configuration
├── views/
│   ├── login.ejs           # Login template
│   ├── register.ejs        # Registration template
│   ├── index.ejs           # File manager UI
│   └── error.ejs           # Error page
├── uploads/                # User file storage (per-user folders)
├── memory-bank/            # AI knowledge base (this folder)
├── db-indexes.js           # MongoDB index creation script
├── README.md               # Setup documentation
└── .github/
    └── copilot-instructions.md # AI agent guidance
```

## Success Timeline
- **Phase 1**: Account management (login/register/session)
- **Phase 2**: File listing & navigation (breadcrumb)
- **Phase 3**: File upload with progress
- **Phase 4**: File operations (rename, delete, search)
- **Phase 5**: Download & zip folders
- **Phase 6**: Testing, security hardening, polish
