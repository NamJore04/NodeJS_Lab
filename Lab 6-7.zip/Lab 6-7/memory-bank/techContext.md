# Tech Context: Technology Stack, Setup & Dependencies

## Technology Stack Summary

| Layer | Technology | Version | Purpose |
|-------|-----------|---------|---------|
| **Runtime** | Node.js | 16+ | JavaScript runtime |
| **Framework** | Express.js | 4.18 | Web server & routing |
| **View Engine** | EJS | 3.1 | Server-side templating |
| **ODM** | Mongoose | 8.0 | MongoDB object mapping |
| **Database** | MongoDB | 8+ | NoSQL document storage |
| **Session Store** | connect-mongo | 5.1 | MongoDB session storage |
| **File Upload** | multer | 1.4.5-lts | Multipart form handling |
| **Password Hash** | bcrypt | 5.1 | Secure password hashing |
| **CSRF Protection** | csurf | 1.11 | CSRF token middleware |
| **Validation** | express-validator | 7.0 | Input validation |
| **Session** | express-session | 1.17 | Session management |
| **Rate Limiting** | express-rate-limit | 7.1 | DDOS prevention |
| **Zip Archive** | archiver | 6.0 | Create zip files |
| **Flash Messages** | connect-flash | 0.1 | User feedback messages |
| **Dev Tool** | nodemon | 3.0 | Auto-restart on file changes |
| **Frontend** | Bootstrap 4.5 | CDN | Responsive UI framework |
| **Frontend** | jQuery | 3.5 | DOM manipulation (CDN) |
| **Frontend** | Font Awesome | 5.3 | Icons (CDN) |

## Current package.json

```json
{
  "name": "file-manager-web-app",
  "version": "1.0.0",
  "description": "Secure file management web application with user authentication",
  "main": "main.js",
  "scripts": {
    "start": "node main.js",
    "dev": "nodemon main.js",
    "db:indexes": "node db-indexes.js"
  },
  "dependencies": {
    "archiver": "^6.0.0",
    "bcrypt": "^5.1.0",
    "connect-flash": "^0.1.1",
    "connect-mongo": "^5.1.0",
    "csurf": "^1.11.0",
    "dotenv": "^16.3.1",
    "ejs": "^3.1.9",
    "express": "^4.18.2",
    "express-rate-limit": "^7.1.0",
    "express-session": "^1.17.3",
    "express-validator": "^7.0.0",
    "mongoose": "^8.0.0",
    "multer": "^1.4.5-lts.1"
  },
  "devDependencies": {
    "nodemon": "^3.0.0"
  }
}
```

## Dependencies Status
✅ All dependencies installed and configured

## Environment Variables (.env)

```env
NODE_ENV=development
PORT=12346

# MongoDB Connection
MONGODB_URI=mongodb://localhost:27017/file_manager_db
# For MongoDB Atlas use:
# MONGODB_URI=mongodb+srv://username:password@cluster.mongodb.net/file_manager_db

# Session
SESSION_SECRET=your-super-secret-key-change-this

# File Upload
UPLOAD_MAX_SIZE=20971520  # 20MB in bytes
UPLOAD_DIR=./uploads

# Security
RATE_LIMIT_WINDOW=900000  # 15 minutes in ms
RATE_LIMIT_MAX=100        # Max requests per window
```

## Database Setup

### MongoDB Collections

**accounts** - User authentication data
```javascript
{
  _id: ObjectId,
  fullname: String (required, trimmed),
  email: String (required, unique, lowercase),
  password: String (required, hashed with bcrypt),
  createdAt: Date (auto),
  updatedAt: Date (auto)
}
// Index: { email: 1 } (unique)
```

**sessions** - Express session storage (managed by connect-mongo)
```javascript
{
  _id: String (session ID),
  expires: Date (TTL index),
  session: Object (session data)
}
```

### Mongoose Connection (config/database.js)

```javascript
require('dotenv').config();
const mongoose = require('mongoose');

const connectDB = async () => {
    try {
        const conn = await mongoose.connect(process.env.MONGODB_URI, {
            // useNewUrlParser and useUnifiedTopology no longer needed in Mongoose 6+
        });
        console.log(`✅ MongoDB Connected: ${conn.connection.host}`);
        return conn;
    } catch (error) {
        console.error(`❌ MongoDB Connection Error: ${error.message}`);
        process.exit(1);
    }
};

module.exports = connectDB;
```

### Creating Indexes (db-indexes.js)

Run `npm run db:indexes` to create optimal indexes:

```javascript
// Creates:
// - Unique index on accounts.email
// - Index on accounts.createdAt
// - TTL index on sessions.expires (auto-delete expired sessions)
```

## Multer Configuration (middleware/multerConfig.js)

```javascript
const multer = require('multer');
const path = require('path');

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const uploadDir = path.join(__dirname, '../uploads', req.session.user.id.toString());
    cb(null, uploadDir);
  },
  filename: (req, file, cb) => {
    // Preserve original filename
    const ext = path.extname(file.originalname);
    const name = path.basename(file.originalname, ext);
    cb(null, `${name}-${Date.now()}${ext}`);
  }
});

const fileFilter = (req, file, cb) => {
  const blockedTypes = ['.exe', '.msi', '.sh'];
  const ext = path.extname(file.originalname).toLowerCase();
  
  if (blockedTypes.includes(ext)) {
    return cb(new Error('File type not allowed'));
  }
  cb(null, true);
};

module.exports = multer({
  storage,
  fileFilter,
  limits: {
    fileSize: 20 * 1024 * 1024 // 20MB
  }
});
```

## Express Middleware Stack (main.js)

```javascript
const express = require('express');
const session = require('express-session');
const csurf = require('csurf');
const rateLimit = require('express-rate-limit');
const flash = require('connect-flash');

const app = express();

// 1. Body parsers
app.use(express.urlencoded({extended: false}));
app.use(express.json());

// 2. Session middleware
app.use(session({
  secret: process.env.SESSION_SECRET,
  resave: false,
  saveUninitialized: true,
  cookie: {
    secure: process.env.NODE_ENV === 'production', // HTTPS only in production
    httpOnly: true,
    sameSite: 'strict',
    maxAge: 24 * 60 * 60 * 1000 // 24 hours
  }
  // store: new MySQLStore({...}) // For production
}));

// 3. CSRF middleware (use session for token storage)
app.use(csurf({cookie: false}));

// 4. Flash messages
app.use(flash());

// 5. Rate limiter
const limiter = rateLimit({
  windowMs: parseInt(process.env.RATE_LIMIT_WINDOW),
  max: parseInt(process.env.RATE_LIMIT_MAX)
});
app.use(limiter);

// 6. View engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// 7. Static files
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// 8. Auth middleware (inject user into locals)
app.use((req, res, next) => {
  res.locals.user = req.session.user || null;
  res.locals.csrfToken = req.csrfToken();
  next();
});

// Routes
app.use('/account', require('./routers/AccountRouter'));
app.use('/', require('./routers/FileRouter'));

// 404 handler
app.get('*', (req, res) => res.status(404).render('error', {code: 404, message: 'Not Found'}));

app.listen(12346, () => console.log('Server running at http://localhost:12346'));
```

## Development Setup Steps

### 1. Prerequisites
- Node.js 16+ installed
- MySQL 8+ running locally or remotely
- npm or yarn

### 2. Clone/Setup Project
```bash
cd "d:\Dai_Hoc_Nam_4\HK1\NodeJS\Lab\Lab 6-7"
npm install
```

### 3. Configure Environment
```bash
# Create .env in project root
echo "DB_HOST=localhost" > .env
echo "DB_USER=root" >> .env
echo "DB_PASSWORD=root" >> .env
echo "DB_NAME=file_manager_db" >> .env
echo "SESSION_SECRET=dev-secret-key" >> .env
```

### 4. Create Directories
```bash
mkdir -p uploads
mkdir -p logs
```

### 5. Initialize Database
```bash
# Option A: Manual SQL
mysql -u root -p < schema.sql

# Option B: Sequelize sync (in code)
sequelize.sync({force: false})
```

### 6. Start Development Server
```bash
npm start
# Nodemon will auto-restart on file changes
# Server listening at http://localhost:12346
```

## Development Commands

```bash
# Start server with auto-reload
npm start

# Run tests (if added)
npm test

# Check for linting issues
npm run lint

# Format code
npm run format

# Clean uploads
npm run clean:uploads
```

## Frontend Asset CDN Links (used in templates)

```html
<!-- Bootstrap CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

<!-- jQuery -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<!-- Popper.js (required for Bootstrap dropdowns/modals) -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

<!-- Bootstrap JS -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

<!-- Font Awesome -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css">
```

## Key File Paths

| File | Purpose |
|------|---------|
| `main.js` | Entry point, middleware setup, route imports |
| `routers/AccountRouter.js` | Auth routes (register, login, logout) |
| `routers/FileRouter.js` | File operations routes (TODO: create) |
| `model/Account.js` | Sequelize Account model definition |
| `middleware/authMiddleware.js` | Session check middleware (TODO: create) |
| `middleware/multerConfig.js` | Multer upload config (TODO: create) |
| `views/login.ejs` | Login form template |
| `views/register.ejs` | Registration form template |
| `views/index.ejs` | File manager UI template |
| `views/error.ejs` | Error page template (TODO: create) |
| `uploads/{userId}/` | User file storage directory |

## Debugging & Troubleshooting

### Common Issues

| Issue | Solution |
|-------|----------|
| `ECONNREFUSED` MySQL | Ensure MySQL running: `service mysql start` (Linux) or check Services (Windows) |
| `CSRF token invalid` | Ensure form includes `<input name="_csrf" value="<%= csrfToken %>">` |
| `File not found in multer` | Check `req.file` exists & upload directory writable |
| `Session not persisting` | Ensure session secret configured & cookies enabled in browser |
| `Port 12346 in use` | Kill process: `lsof -i :12346` (Linux) or check Task Manager (Windows) |

### Debug Mode

```bash
# Enable debug logging
DEBUG=express:* npm start

# Check Node version
node --version

# Check installed packages
npm list
```

## Security Best Practices Applied

1. ✅ **Password Hashing**: bcrypt with salt rounds 10+
2. ✅ **CSRF Protection**: csurf middleware + tokens in forms
3. ✅ **SQL Injection**: Sequelize parameterized queries (no raw SQL)
4. ✅ **Session Hijacking**: httpOnly, secure, sameSite cookies
5. ✅ **File Upload**: File type validation, size limits, isolated storage
6. ✅ **Path Traversal**: Validate & sanitize file paths (no `../`)
7. ✅ **Rate Limiting**: Prevent DDOS with express-rate-limit
8. ✅ **Error Handling**: Don't expose stack traces to users (dev only)
