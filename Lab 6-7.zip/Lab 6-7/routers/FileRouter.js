const express = require('express');
const path = require('path');
const fs = require('fs').promises;
const fsSync = require('fs');
const archiver = require('archiver');
const { authMiddleware } = require('../middleware/authMiddleware');
const upload = require('../middleware/multerConfig');

const router = express.Router();

// Middleware
router.use(express.json());
router.use(express.urlencoded({ extended: false }));
router.use(authMiddleware);

// Helper function to get user directory
const getUserDir = (userId, subPath = '') => {
    const baseDir = path.join(__dirname, '../uploads', userId.toString());
    if (subPath) {
        // Normalize web paths (/) to system paths (\ on Windows, / on Unix)
        const normalizedPath = subPath.replace(/\//g, path.sep);
        return path.join(baseDir, normalizedPath);
    }
    return baseDir;
};

// Helper function to ensure directory exists
const ensureDir = async (dirPath) => {
    try {
        await fs.access(dirPath);
    } catch {
        await fs.mkdir(dirPath, { recursive: true });
    }
};

// GET / - File manager home
router.get('/', async (req, res) => {
    try {
        const userDir = getUserDir(req.session.user.id);
        await ensureDir(userDir);

        const currentPath = req.query.path || '';
        const fullPath = getUserDir(req.session.user.id, currentPath);

        // Security check - prevent path traversal
        if (!fullPath.startsWith(userDir)) {
            return res.status(403).render('error', { code: 403, message: 'Access denied' });
        }

        const items = await fs.readdir(fullPath, { withFileTypes: true });
        const files = [];

        for (const item of items) {
            const itemPath = path.join(fullPath, item.name);
            const stats = await fs.stat(itemPath);
            
            // Build web-safe path (use forward slashes)
            const webPath = currentPath 
                ? (currentPath + '/' + item.name).replace(/\\/g, '/')
                : item.name;
            
            files.push({
                name: item.name,
                isDirectory: item.isDirectory(),
                size: item.isDirectory() ? '-' : (stats.size / 1024).toFixed(2) + ' KB',
                modified: stats.mtime.toLocaleDateString(),
                path: webPath
            });
        }

        // Sort: folders first, then files
        files.sort((a, b) => {
            if (a.isDirectory && !b.isDirectory) return -1;
            if (!a.isDirectory && b.isDirectory) return 1;
            return a.name.localeCompare(b.name);
        });

        // Build breadcrumb
        const breadcrumb = [];
        if (currentPath) {
            // Split by both forward and backward slashes
            const parts = currentPath.split(/[/\\]/);
            let accumulated = '';
            breadcrumb.push({ name: 'Home', path: '' });
            parts.forEach(part => {
                accumulated = accumulated ? (accumulated + '/' + part) : part;
                breadcrumb.push({ name: part, path: accumulated });
            });
        } else {
            breadcrumb.push({ name: 'Home', path: '' });
        }

        res.render('index', {
            user: req.session.user,
            files,
            currentPath,
            breadcrumb,
            csrfToken: req.csrfToken(),
            success: req.flash('success'),
            error: req.flash('error')
        });
    } catch (error) {
        console.error('File listing error:', error);
        res.render('error', { code: 500, message: 'Failed to list files' });
    }
});

// GET /api/files - JSON file listing
router.get('/api/files', async (req, res) => {
    try {
        const currentPath = req.query.path || '';
        const userDir = getUserDir(req.session.user.id);
        const fullPath = getUserDir(req.session.user.id, currentPath);

        if (!fullPath.startsWith(userDir)) {
            return res.status(403).json({ success: false, error: 'Access denied' });
        }

        const items = await fs.readdir(fullPath, { withFileTypes: true });
        const files = [];

        for (const item of items) {
            const itemPath = path.join(fullPath, item.name);
            const stats = await fs.stat(itemPath);
            
            // Build web-safe path (use forward slashes)
            const webPath = currentPath 
                ? (currentPath + '/' + item.name).replace(/\\/g, '/')
                : item.name;
            
            files.push({
                name: item.name,
                isDirectory: item.isDirectory(),
                size: item.isDirectory() ? '-' : (stats.size / 1024).toFixed(2) + ' KB',
                modified: stats.mtime.toLocaleDateString(),
                path: webPath
            });
        }

        files.sort((a, b) => {
            if (a.isDirectory && !b.isDirectory) return -1;
            if (!a.isDirectory && b.isDirectory) return 1;
            return a.name.localeCompare(b.name);
        });

        res.json({ success: true, files });
    } catch (error) {
        console.error('API file listing error:', error);
        res.status(500).json({ success: false, error: 'Failed to list files' });
    }
});

// POST /api/files/upload
router.post('/api/files/upload', upload.single('file'), async (req, res) => {
    try {
        if (!req.file) {
            return res.status(400).json({ success: false, error: 'No file uploaded' });
        }

        // Get current path from query
        const currentPath = req.query.path || '';
        // Build web-safe path (use forward slashes)
        const filePath = currentPath 
            ? (currentPath + '/' + req.file.filename).replace(/\\/g, '/')
            : req.file.filename;

        res.json({
            success: true,
            file: {
                name: req.file.filename,
                size: (req.file.size / 1024).toFixed(2) + ' KB',
                path: filePath
            }
        });
    } catch (error) {
        console.error('Upload error:', error);
        res.status(500).json({ success: false, error: error.message || 'Upload failed' });
    }
});

// POST /api/files/mkdir
router.post('/api/files/mkdir', async (req, res) => {
    try {
        const { folderName, currentPath } = req.body;

        if (!folderName || /[<>:"|?*]/.test(folderName)) {
            return res.status(400).json({ success: false, error: 'Invalid folder name' });
        }

        const userDir = getUserDir(req.session.user.id);
        const targetPath = getUserDir(req.session.user.id, currentPath || '');
        const newFolderPath = path.join(targetPath, folderName);

        if (!newFolderPath.startsWith(userDir)) {
            return res.status(403).json({ success: false, error: 'Access denied' });
        }

        await fs.mkdir(newFolderPath, { recursive: true });
        res.json({ success: true, message: 'Folder created successfully' });
    } catch (error) {
        console.error('Create folder error:', error);
        res.status(500).json({ success: false, error: 'Failed to create folder' });
    }
});

// POST /api/files/rename
router.post('/api/files/rename', async (req, res) => {
    try {
        const { oldPath, newName } = req.body;

        if (!oldPath || !newName || /[<>:"|?*]/.test(newName)) {
            return res.status(400).json({ success: false, error: 'Invalid file name' });
        }

        const userDir = getUserDir(req.session.user.id);
        const oldFullPath = getUserDir(req.session.user.id, oldPath);
        const newFullPath = path.join(path.dirname(oldFullPath), newName);

        if (!oldFullPath.startsWith(userDir) || !newFullPath.startsWith(userDir)) {
            return res.status(403).json({ success: false, error: 'Access denied' });
        }

        // Check if file/folder exists before attempting to rename
        try {
            await fs.access(oldFullPath);
        } catch (error) {
            return res.status(404).json({ success: false, error: 'File or folder not found' });
        }

        await fs.rename(oldFullPath, newFullPath);
        res.json({ success: true, message: 'Renamed successfully' });
    } catch (error) {
        console.error('Rename error:', error);
        res.status(500).json({ success: false, error: 'Failed to rename' });
    }
});

// DELETE /api/files
router.delete('/api/files', async (req, res) => {
    try {
        const { filePath } = req.body;

        if (!filePath) {
            return res.status(400).json({ success: false, error: 'File path required' });
        }

        const userDir = getUserDir(req.session.user.id);
        const fullPath = getUserDir(req.session.user.id, filePath);

        if (!fullPath.startsWith(userDir)) {
            return res.status(403).json({ success: false, error: 'Access denied' });
        }

        // Check if file/folder exists before attempting to delete
        try {
            await fs.access(fullPath);
        } catch (error) {
            return res.status(404).json({ success: false, error: 'File or folder not found' });
        }

        const stats = await fs.stat(fullPath);
        if (stats.isDirectory()) {
            await fs.rm(fullPath, { recursive: true, force: true });
        } else {
            await fs.unlink(fullPath);
        }

        res.json({ success: true, message: 'Deleted successfully' });
    } catch (error) {
        console.error('Delete error:', error);
        res.status(500).json({ success: false, error: 'Failed to delete' });
    }
});

// GET /api/files/download
router.get('/api/files/download', async (req, res) => {
    try {
        const { path: filePath } = req.query;

        if (!filePath) {
            return res.status(400).send('File path required');
        }

        const userDir = getUserDir(req.session.user.id);
        const fullPath = getUserDir(req.session.user.id, filePath);

        if (!fullPath.startsWith(userDir)) {
            return res.status(403).send('Access denied');
        }

        // Check if file/folder exists before attempting to download
        try {
            await fs.access(fullPath);
        } catch (error) {
            return res.status(404).send('File or folder not found');
        }

        const stats = await fs.stat(fullPath);

        if (stats.isDirectory()) {
            // Create zip file for folder (as required by Lab spec)
            const zipName = `${path.basename(fullPath)}.zip`;
            const zipPath = path.join(userDir, `temp_${Date.now()}_${zipName}`);
            
            // Create zip file on disk
            const output = fsSync.createWriteStream(zipPath);
            const archive = archiver('zip', { zlib: { level: 9 } });

            output.on('close', async () => {
                // After zip is created, send it to client
                res.download(zipPath, zipName, async (err) => {
                    // Delete zip file after download completes (as required by Lab spec)
                    try {
                        await fs.unlink(zipPath);
                        console.log(`Deleted temporary zip: ${zipPath}`);
                    } catch (unlinkErr) {
                        console.error('Failed to delete zip:', unlinkErr);
                    }

                    if (err) {
                        console.error('Download error:', err);
                    }
                });
            });

            archive.on('error', (err) => {
                console.error('Archive error:', err);
                res.status(500).send('Failed to create zip');
            });

            archive.pipe(output);
            archive.directory(fullPath, false);
            await archive.finalize();
        } else {
            // Download single file
            res.download(fullPath, path.basename(fullPath));
        }
    } catch (error) {
        console.error('Download error:', error);
        res.status(500).send('Download failed');
    }
});

// GET /api/files/search
router.get('/api/files/search', async (req, res) => {
    try {
        const { q, path: currentPath } = req.query;

        if (!q) {
            return res.json({ success: true, files: [] });
        }

        const userDir = getUserDir(req.session.user.id);
        const searchPath = getUserDir(req.session.user.id, currentPath || '');

        if (!searchPath.startsWith(userDir)) {
            return res.status(403).json({ success: false, error: 'Access denied' });
        }

        const items = await fs.readdir(searchPath, { withFileTypes: true });
        const filtered = [];

        for (const item of items) {
            if (item.name.toLowerCase().includes(q.toLowerCase())) {
                const itemPath = path.join(searchPath, item.name);
                const stats = await fs.stat(itemPath);

                // Build web-safe path (use forward slashes)
                const webPath = currentPath 
                    ? (currentPath + '/' + item.name).replace(/\\/g, '/')
                    : item.name;

                filtered.push({
                    name: item.name,
                    isDirectory: item.isDirectory(),
                    size: item.isDirectory() ? '-' : (stats.size / 1024).toFixed(2) + ' KB',
                    modified: stats.mtime.toLocaleDateString(),
                    path: webPath
                });
            }
        }

        res.json({ success: true, files: filtered });
    } catch (error) {
        console.error('Search error:', error);
        res.status(500).json({ success: false, error: 'Search failed' });
    }
});

module.exports = router;
