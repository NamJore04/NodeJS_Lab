const express = require('express');
const bcrypt = require('bcrypt');
const { body, validationResult } = require('express-validator');
const Account = require('../models/Account');
const { guestMiddleware } = require('../middleware/authMiddleware');

const router = express.Router();

// Middleware
router.use(express.urlencoded({ extended: false }));

// GET /account/login
router.get('/login', guestMiddleware, (req, res) => {
    res.render('login', {
        csrfToken: req.csrfToken(),
        error: req.flash('error'),
        success: req.flash('success')
    });
});

// GET /account/register
router.get('/register', guestMiddleware, (req, res) => {
    res.render('register', {
        csrfToken: req.csrfToken(),
        error: req.flash('error'),
        success: req.flash('success')
    });
});

// POST /account/register
router.post('/register', [
    body('name').trim().notEmpty().withMessage('Fullname is required'),
    body('email').isEmail().withMessage('Invalid email address'),
    body('password').isLength({ min: 6 }).withMessage('Password must be at least 6 characters'),
    body('confirmPassword').custom((value, { req }) => {
        if (value !== req.body.password) {
            throw new Error('Passwords do not match');
        }
        return true;
    })
], async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        req.flash('error', errors.array()[0].msg);
        return res.redirect('/account/register');
    }

    try {
        const { name, email, password } = req.body;

        // Check if email already exists
        const existingUser = await Account.findOne({ email: email.toLowerCase() });
        if (existingUser) {
            req.flash('error', 'Email already registered');
            return res.redirect('/account/register');
        }

        // Hash password
        const hashedPassword = await bcrypt.hash(password, 10);

        // Create user
        const user = await Account.create({
            fullname: name,
            email: email.toLowerCase(),
            password: hashedPassword
        });

        // Set session
        req.session.user = {
            id: user._id.toString(),
            fullname: user.fullname,
            email: user.email
        };

        req.flash('success', 'Registration successful!');
        res.redirect('/');
    } catch (error) {
        console.error('Registration error:', error);
        req.flash('error', 'Registration failed. Please try again.');
        res.redirect('/account/register');
    }
});

// POST /account/login
router.post('/login', [
    body('email').isEmail().withMessage('Invalid email address'),
    body('password').notEmpty().withMessage('Password is required')
], async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        req.flash('error', errors.array()[0].msg);
        return res.redirect('/account/login');
    }

    try {
        const { email, password } = req.body;

        // Find user
        const user = await Account.findOne({ email: email.toLowerCase() });
        if (!user) {
            req.flash('error', 'Invalid email or password');
            return res.redirect('/account/login');
        }

        // Compare password
        const isValid = await bcrypt.compare(password, user.password);
        if (!isValid) {
            req.flash('error', 'Invalid email or password');
            return res.redirect('/account/login');
        }

        // Set session
        req.session.user = {
            id: user._id.toString(),
            fullname: user.fullname,
            email: user.email
        };

        req.flash('success', 'Login successful!');
        res.redirect('/');
    } catch (error) {
        console.error('Login error:', error);
        req.flash('error', 'Login failed. Please try again.');
        res.redirect('/account/login');
    }
});

// GET /account/logout
router.get('/logout', (req, res) => {
    req.session.destroy((err) => {
        if (err) {
            console.error('Logout error:', err);
        }
        res.redirect('/account/login');
    });
});

module.exports = router;
