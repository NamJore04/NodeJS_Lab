const express = require('express');
const path = require('path');
const session = require('express-session');
const flash = require('connect-flash');
const morgan = require('morgan');
const rateLimit = require('express-rate-limit');
const usersRouter = require('./routes/users');
const rawBodyParser = require('./middleware/rawBodyParser');

const app = express();
const PORT = process.env.PORT || 3000;

app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');
app.use('/public', express.static(path.join(__dirname, 'public')));
app.use(morgan('dev'));
app.use(session({ secret: 'lab05-secret', resave: false, saveUninitialized: true }));
app.use(flash());

const limiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 200,
  standardHeaders: true,
  legacyHeaders: false,
  message: 'Too many requests, please try again later.'
});
app.use(limiter);

app.use(rawBodyParser);

app.use((req, res, next) => {
  res.locals.success = req.flash('success');
  res.locals.error = req.flash('error');
  next();
});

app.get('/', (req, res) => res.redirect('/users'));
app.use('/users', usersRouter);

app.use((req, res, next) => {
  res.status(404);
  res.redirect('/error');
});

app.get('/error', (req, res) => {
  res.status(404).render('error', { messages: req.flash() });
});

app.use((err, req, res, next) => {
  console.error(err);
  req.flash('error', err.message || 'Internal server error');
  res.status(500).render('error', { messages: req.flash() });
});

app.listen(PORT, () => console.log(`Server started on http://localhost:${PORT}`));