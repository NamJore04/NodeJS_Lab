module.exports = function rawBodyParser(req, res, next) {
  const methodsWithBody = ['POST', 'PUT', 'PATCH', 'DELETE'];
  if (!methodsWithBody.includes(req.method)) return next();

  let data = '';
  req.setEncoding('utf8');
  req.on('data', chunk => {
    data += chunk;
    if (data.length > 1e6) req.connection.destroy();
  });

  req.on('end', () => {
    const contentType = (req.headers['content-type'] || '').split(';')[0];
    try {
      if (contentType === 'application/json') {
        req.body = data ? JSON.parse(data) : {};
      } else if (contentType === 'application/x-www-form-urlencoded') {
        req.body = {};
        data.split('&').forEach(pair => {
          if (!pair) return;
          const [k, v] = pair.split('=').map(decodeURIComponent);
          req.body[k] = v;
        });
      } else {
        req.body = data;
      }
    } catch (err) {
      return next(err);
    }
    next();
  });
};