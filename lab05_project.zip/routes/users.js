const express = require('express');
const router = express.Router();
const axios = require('axios');
const { API_BASE } = require('../config/api');
const { body, validationResult } = require('express-validator');

router.get('/', async (req, res, next) => {
  try {
    const r = await axios.get(`${API_BASE}/users`);
    res.render('users_list', { users: r.data, messages: req.flash() });
  } catch (err) { next(err); }
});

router.get('/create', (req, res) => {
  res.render('users_form', { user: {}, errors: {}, messages: req.flash() });
});

router.post('/create',
  [
    body('name').trim().notEmpty().withMessage('Name is required'),
    body('email').isEmail().withMessage('Invalid email'),
    body('age').optional().isInt({ min: 0 }).withMessage('Age must be a positive integer')
  ],
  async (req, res, next) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.render('users_form', { user: req.body, errors: errors.mapped(), messages: req.flash() });
    }
    try {
      await axios.post(`${API_BASE}/users`, req.body);
      req.flash('success', 'Thêm user thành công');
      res.redirect('/users');
    } catch (err) { next(err); }
  }
);

router.get('/:id', async (req, res, next) => {
  try {
    const r = await axios.get(`${API_BASE}/users/${req.params.id}`);
    res.render('users_detail', { user: r.data, messages: req.flash() });
  } catch (err) {
    if (err.response && err.response.status === 404) {
      req.flash('error', 'User không tồn tại');
      return res.redirect('/users');
    }
    next(err);
  }
});

router.get('/:id/edit', async (req, res, next) => {
  try {
    const r = await axios.get(`${API_BASE}/users/${req.params.id}`);
    res.render('users_form', { user: r.data, errors: {}, messages: req.flash() });
  } catch (err) { next(err); }
});

router.post('/:id/edit',
  [
    body('name').trim().notEmpty().withMessage('Name is required'),
    body('email').isEmail().withMessage('Invalid email'),
    body('age').optional().isInt({ min: 0 }).withMessage('Age must be a positive integer')
  ],
  async (req, res, next) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      req.body.id = req.params.id;
      return res.render('users_form', { user: req.body, errors: errors.mapped(), messages: req.flash() });
    }
    try {
      await axios.put(`${API_BASE}/users/${req.params.id}`, req.body);
      req.flash('success', 'Cập nhật user thành công');
      res.redirect('/users');
    } catch (err) { next(err); }
  }
);

router.post('/:id/delete', async (req, res, next) => {
  try {
    await axios.delete(`${API_BASE}/users/${req.params.id}`);
    req.flash('success', 'Xóa user thành công');
    res.redirect('/users');
  } catch (err) { next(err); }
});

module.exports = router;