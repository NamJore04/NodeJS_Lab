module.exports = {
  API_BASE: process.env.API_BASE || 'http://localhost:5000'
};